import numpy as np
import matplotlib.pyplot as plt

class Scenario():

    def __init__(self,
                 mtd_angle_range = [0, np.pi], # Radians
                 mtd_dist_range = [20, 100], # Meters
                 mtd_ant_gain_dB = 5,
                 mtd_proc_power_density = 7.75, # Watts/s
                 mtd_tx_power = 10e-3, # Watts
                 mtd_pa_ineff = 2.0,

                 bs_angle = np.pi/4, # Radians
                 bs_dist = 20, # Meters
                 bs_ant_gain_dB = 5,
                 bs_proc_power_density = 1715, # Watts/s
                 bs_tx_power = 100e-3, # Watts
                 bs_pa_ineff = 1.6,
                
                 ris_num_els_x = 10,
                 ris_num_els_z = 10,
                 ris_el_size = 0.1, # Meters 
                 ris_el_power_density = 3, # Watts/s

                 carrier_freq = 3e9,
                 num_time_slots = 20,
                 noise_power_dBm = -86,
                 blockage_att_dB = 40,
                 sic_snr_threshold_dB = 0,
                 pilot_length = 1,
                 
                 access_slot_time = 40e-6,
                 training_slot_time = 8e-6,
                 sigma_slot_time = 4e-6):
        
        self.tdma_frame_duration = num_time_slots*(training_slot_time + access_slot_time) + sigma_slot_time

        self.mtd_ant_gain = 10**(mtd_ant_gain_dB/10)
        self.mtd_tx_power = mtd_tx_power
        self.mtd_tx_energy = mtd_tx_power * access_slot_time
        self.mtd_proc_power_density = mtd_proc_power_density
        self.mtd_proc_power = mtd_proc_power_density * self.tdma_frame_duration
        self.mtd_angle_range = mtd_angle_range
        self.mtd_dist_range = mtd_dist_range
        self.mtd_pa_ineff = mtd_pa_ineff
        
        self.bs_ant_gain = 10**(bs_ant_gain_dB/10)
        self.bs_tx_power = bs_tx_power
        self.bs_tx_energy = bs_tx_power * training_slot_time
        self.bs_proc_power_density = bs_proc_power_density
        self.bs_proc_power = self.bs_proc_power_density * self.tdma_frame_duration
        self.bs_angle = bs_angle
        self.bs_dist = bs_dist
        self.bs_pa_ineff = bs_pa_ineff

        self.ris_el_power_density = ris_el_power_density
        self.ris_el_power = ris_el_power_density * self.tdma_frame_duration
        self.ris_num_els_x = ris_num_els_x
        self.ris_num_els_z = ris_num_els_z
        self.ris_num_els = ris_num_els_x * ris_num_els_z
        self.ris_el_size = ris_el_size

        self.carrier_freq = carrier_freq
        self.num_time_slots = num_time_slots
        self.noise_power = 10**(noise_power_dBm/10) * 1e-3
        self.sic_snr_threshold = 10**(sic_snr_threshold_dB/10)
        self.blockage_att_dB = blockage_att_dB

        self.ris_num_els = self.ris_num_els_x * self.ris_num_els_z
        self.wave_number = ((2*np.pi)/(3e8)) * self.carrier_freq

        self.training_slot_time = training_slot_time
        self.access_slot_time = access_slot_time
        self.sigma_slot_time = sigma_slot_time
        self.pilot_length = pilot_length
        
        self.training_ratio = self.training_slot_time / self.access_slot_time

    def plot(self, num_cont_mtds=100, angle_data=None, dist_data=None, axis=None):

        '''
        Plots the communication cell defined in the scenario class. By default, 100 MTDs are randomly positioned following a uniform distribution.
        The MTDs' positions can also be passed to this function through 'angle_data' and 'dist_data' parameters.

        Parameters:
            num_cont_mtds: Number of contending MTDs to plot.
            angle_data   : Angular positions of MTDs.
            dist_data    : Distance positions of MTDs.
            axis         : The axis to realize the plot.
        
    Outputs:
            None
        '''

        if axis == None:

            _, axis = plt.subplots(ncols=1, nrows=1, layout='tight', subplot_kw = {'projection': 'polar'})

        #- Plotting MTDs' positions:

        if angle_data is None and dist_data is None:
            ch = Channel(self)
            (mtds_dists, mtds_angles) = ch.generateMtdsPositions(num_cont_mtds=num_cont_mtds)
        
        else:
            mtds_dists, mtds_angles = dist_data, angle_data

        axis.scatter(mtds_angles, mtds_dists, color='#165FF2', marker='x', s=15, label='Users')

        #- Plotting cell limits:

        cell_limits_part1_angles = np.array([self.mtd_angle_range[0], self.mtd_angle_range[0]])
        cell_limits_part1_dists = np.array([self.mtd_dist_range[0], self.mtd_dist_range[1]])
        
        cell_limits_part2_angles = np.linspace(self.mtd_angle_range[0], self.mtd_angle_range[1], 1000)
        cell_limits_part2_dists = np.full(cell_limits_part2_angles.shape, self.mtd_dist_range[1])
        
        cell_limits_part3_angles = np.array([self.mtd_angle_range[1], self.mtd_angle_range[1]])
        cell_limits_part3_dists = np.array([self.mtd_dist_range[1], self.mtd_dist_range[0]])
        
        cell_limits_part4_angles = np.linspace(self.mtd_angle_range[1], self.mtd_angle_range[0], 1000)
        cell_limits_part4_dists = np.full(cell_limits_part4_angles.shape, self.mtd_dist_range[0])

        cell_limits_angles = np.concatenate([cell_limits_part1_angles, cell_limits_part2_angles, cell_limits_part3_angles, cell_limits_part4_angles])
        cell_limits_dists = np.concatenate([cell_limits_part1_dists, cell_limits_part2_dists, cell_limits_part3_dists, cell_limits_part4_dists])

        axis.plot(cell_limits_angles, cell_limits_dists, ls='--', color='#F21667', lw=1.5, label='Cell Limits')

        #- Plotting the BS:
        axis.scatter(self.bs_angle + np.pi/2, self.bs_dist, marker='^', color='#4BF2E2', label='Base Station', s=60)

        #- Plottingn the RIS
        axis.scatter(0, 0, marker='s', color='#F21BA7', label='RIS', s=60)

        #: The scenario plotted can be viewed by using the method matplotlib.pyplot.show() in your main script.

    def adjustSlotTimes(self, tdma_frame_duration, training_access_ratio = 0.2, sigma_access_ratio = 0.1):

        '''
        Ajusts the duration of access, sigma and training slots while keeping the TDMA frame durations constant.
        The training access ratio Tts/Tas and the sigma access ratio Tσ/Tas also remains constant. The adjustments
        are made directly in the atributes of the scenario class.

        Parameters:
            tdma_frame_duration  : The total duration of the whole TDMA frame (considering the training phase), Tf.
            training_access_ratio: Tts/Tas, 0.2 by default.
            sigma_access_ratio   : Tσ/Tas, 0.1 by default.
        
        Outputs:
            None
        '''

        #- Here, we just want to adjust the duration of the TDMA frame. The power spent in each frame must remain constant

        self.access_slot_time = tdma_frame_duration / (self.num_time_slots * training_access_ratio + sigma_access_ratio + self.num_time_slots)
        self.sigma_slot_time = self.access_slot_time * sigma_access_ratio
        self.training_slot_time = self.access_slot_time * training_access_ratio

        self.tdma_frame_duration = tdma_frame_duration
        self.training_ratio = self.training_slot_time / self.access_slot_time

        #- Adjusting the uplink energies:
        self.mtd_tx_energy = self.mtd_tx_power * self.access_slot_time
        self.bs_tx_energy = self.bs_tx_power * self.training_slot_time

        #: The scenario class atributes have been adjusted.

class Channel():

    def __init__(self, scenario):

        assert isinstance(scenario, Scenario), "Verify if input 'scenario' is a Scenario Class."

        self.bs_ant_gain = scenario.bs_ant_gain
        self.bs_dist = scenario.bs_dist
        self.bs_angle = scenario.bs_angle

        self.ris_num_els_x = scenario.ris_num_els_x
        self.ris_num_els_z = scenario.ris_num_els_z
        self.ris_el_size = scenario.ris_el_size

        self.mtd_ant_gain = scenario.mtd_ant_gain
        self.mtd_angle_range = scenario.mtd_angle_range
        self.mtd_dist_range = scenario.mtd_dist_range

        self.num_time_slots = scenario.num_time_slots
        self.wave_number = scenario.wave_number
        self.blockage_att_dB = scenario.blockage_att_dB
        self.carrier_freq = scenario.carrier_freq

    def generateMtdsPositions(self, num_cont_mtds):

        '''
        Generate the positions of the contending MTDs. The positions follows a uniform distribution.

        Parameters:
            num_cont_mtds: Number of contending MTDs to generate.

        Outputs:
            dists : Vector with dimension containing the distances from the contending MTDs to the RIS center (origin).
            angles: Vector with dimension containing the angles between the contending MTDs and the RIS center.
        '''

        dist_min = self.mtd_dist_range[0]
        dist_max = self.mtd_dist_range[1]
        angle_min = self.mtd_angle_range[0]
        angle_max = self.mtd_angle_range[1]

        dists_cdf = np.random.uniform(low=0, high=1, size=(num_cont_mtds))
        dists = np.sqrt(dist_min**2 + (dist_max**2 - dist_min**2) * dists_cdf)

        angles = np.random.uniform(low=angle_min, high=angle_max, size=(num_cont_mtds))

        return dists, angles

    def generateChannelCoefficients(self,
                                    num_cont_mtds,
                                    direct_link=True,
                                    include_nlos_components=True,
                                    random_upos=True,
                                    return_upos=False,
                                    mtds_dists=None,
                                    mtds_angles=None,
                                    riccian_factors=(3/7, 9/1, 6/4)):
        
        '''
        Generate the channel coefficients of the contending MTDs according to specified parameters.

        Parameters:
            num_cont_mtds         : Number of contending MTDs.
            direct_link           : Specifies if the direct link between MTDs and BS is computed.
                                    For MTDs behind the blockage, applies the attenuation scenario.blockage_att_dB from the scenario class.
            include_nlos_component: Specifies if small scale fading is modeled. If False, the channel is purely LoS / Virtual LoS.
            random_upos           : If True, MTDs positioned are randomly generated. If False, mtds_dists and mtds_angles must be informed.
            return_upos           : If True, also retuns the generated MTDs positions.
            mtds_dists            : Distance positions of MTDs.
            mtds_angles           : Angular positions of MTDs.
            riccian_factors       : Tuple of three elements containing the rice factors of red area direct link, green area direct link and reflected link.

    Outputs:
            channel_coeffs           : 2D array containing the channel coefficients of each MTD in each time slot.
            (mtds_angles, mtds_dists): Generated positions of MTDS (only if return_upos==True).
        '''

        #- Generate the contending MTDs positions (number of contending MTDs x 1)
        if random_upos:

            (mtds_dists, mtds_angles) = self.generateMtdsPositions(num_cont_mtds)

        else:

            # Checks if the angles and dists were informed:
            if mtds_dists is None or mtds_angles is None:

                raise AttributeError("Users positions cannot be generated automatically when 'random_upos' is False. Please inform 'mtds_dists' and 'mtds_angles' manually.")

        blockage_att_dB = np.full_like(mtds_angles, 0, dtype=float)

        #- If direct_link==True, compute the channel coefficients of the direct link for all users. If not, compute it just for MTDs in the green area:
        if direct_link:

            direct_link_mask = np.ones_like(mtds_angles, dtype=bool)
            blockage_att_dB[mtds_angles < np.pi/2] = self.blockage_att_dB

        else:

            direct_link_mask = mtds_angles > np.pi/2
            
        mtds_pos = mtds_dists * np.exp(1j*mtds_angles)
        ap_pos = self.bs_dist * np.exp(1j*(self.bs_angle + np.pi/2))
        direct_link_dists = np.abs(mtds_pos - ap_pos)
        path_loss_dir = self.bs_ant_gain * self.mtd_ant_gain / ((4*np.pi*direct_link_dists)**2 * 10**(blockage_att_dB/10)) * (3e8 / self.carrier_freq)**2
        
        phase_shift_dir = np.random.uniform(0, 2*np.pi, size=mtds_angles.size)

        #- Compute the RIS configurations (1 X number of time slots X number of RIS elements in x direction)
        ris_angles = np.linspace(5*np.pi/180, 85*np.pi/180, self.num_time_slots, endpoint=True)
        ris_indices = np.arange(1, self.ris_num_els_x + 1, 1)
        ris_ref_coeffs = self.wave_number * self.ris_el_size * (np.sin(self.bs_angle) - np.sin(ris_angles)).reshape((self.num_time_slots, 1)) * ris_indices

        #- Compute the path-loss:
        path_loss_ref = (self.bs_ant_gain * self.mtd_ant_gain) / (4*np.pi)**2 * (self.ris_el_size**2 / self.bs_dist)**2 * (np.cos(np.pi/2 - mtds_angles) / (mtds_dists))**2

        #- Compute the total phase-shift:
        phase_shift_ref = - self.wave_number * (self.bs_dist + mtds_dists - (np.sin(self.bs_angle) - np.sin(np.pi/2 - mtds_angles)) * (self.ris_num_els_x + 1)/2 * self.ris_el_size)

        #- Compute the array factor:
        array_factor = np.zeros(shape=(num_cont_mtds, self.num_time_slots), dtype=complex)
        for kk, _ in enumerate(range(num_cont_mtds)):

            for ss, _ in enumerate(range(self.num_time_slots)):

                array_factor[kk, ss] = self.ris_num_els_z * np.sum(np.exp(1j*(self.wave_number*(np.sin(np.pi/2 - mtds_angles[kk]) - np.sin(self.bs_angle)) * ris_indices * self.ris_el_size + ris_ref_coeffs[ss, :])))

        #- Compute the channel coefficients:
        if include_nlos_components:
            
            nlos_ref = np.sqrt(path_loss_ref.reshape(num_cont_mtds, 1)/2) * (np.random.randn(num_cont_mtds, self.num_time_slots) + 1j*np.random.randn(num_cont_mtds, self.num_time_slots))
            los_ref = (np.sqrt(path_loss_ref) * np.exp(1j*phase_shift_ref)).reshape(num_cont_mtds, 1) * array_factor
            channel_coeffs_ref = np.sqrt(riccian_factors[2]/(1+riccian_factors[2])) * los_ref + np.sqrt(1/(1+riccian_factors[2])) * nlos_ref

            nlos_dir = np.sqrt(path_loss_dir.reshape(num_cont_mtds, 1)/2) * (np.random.randn(num_cont_mtds, self.num_time_slots) + 1j*np.random.randn(num_cont_mtds, self.num_time_slots))
            los_dir = np.tile((np.sqrt(path_loss_dir) * np.exp(1j*phase_shift_dir) * direct_link_mask).reshape(num_cont_mtds, 1), self.num_time_slots)
            rice_factor_mask = mtds_angles > np.pi/2

            channel_coeffs_dir = np.zeros((num_cont_mtds, self.num_time_slots), dtype=complex)
            channel_coeffs_dir[rice_factor_mask, :] = (np.sqrt(riccian_factors[1]/(1+riccian_factors[1])) * los_dir[rice_factor_mask, :] + np.sqrt(1/(1+riccian_factors[1])) * nlos_dir[rice_factor_mask, :])
            channel_coeffs_dir[~rice_factor_mask, :] = (np.sqrt(riccian_factors[0]/(1+riccian_factors[0])) * los_dir[~rice_factor_mask, :] + np.sqrt(1/(1+riccian_factors[0])) * nlos_dir[~rice_factor_mask, :])

        else:

            channel_coeffs_ref = (np.sqrt(path_loss_ref) * np.exp(1j * phase_shift_ref)).reshape(num_cont_mtds, 1) * array_factor
            channel_coeffs_dir = np.tile((np.sqrt(path_loss_dir) * np.exp(1j*phase_shift_dir) * direct_link_mask).reshape(num_cont_mtds, 1), self.num_time_slots)
    
        channel_coeffs = channel_coeffs_ref + channel_coeffs_dir

        if return_upos:

            return channel_coeffs, (mtds_angles, mtds_dists)
        else:

            return channel_coeffs

class AccessPolicy():

    def __init__(self):
        pass

    def strongestConfigurationPolicy(self, channel_qualities):
        
        '''
        Strongest-Configuration Access Policy (SCP). MTDs transmits a single replica in the strongest slot.

        Parameters:
            channel_qualities: Matrix containing the channel qualities.

        Outputs:
            policy: Binary matrix with decisions taken by MTDs, where 1 denotes transmission and 0 denotes idle.
        '''

        policy = (channel_qualities.T == np.max(channel_qualities, axis=1).reshape(-1)).T

        return policy

    def configurationAwareRandomPolicy(self, channel_qualities):
        
        '''
        Configuration-Aware Random Access Policy (CARP). MTDs transmits in a given slot according to a probability proportional to the respective channel quality.

         Parameters:
            channel_qualities: Matrix containing the channel qualities.

        Outputs:
            policy: Binary matrix with decisions taken by MTDs, where 1 denotes transmission and 0 denotes idle.
        '''

        num_contending_mtds, _ = np.shape(channel_qualities)
        probs = channel_qualities / np.sum(channel_qualities, axis=1, keepdims=True)

        policy = np.random.uniform(low=0, high=1, size=np.shape(channel_qualities)) < probs

        #- If none of the available time slots was selected randomly, chose the time slot with better channel quality to transmit:
        for i in range(num_contending_mtds):
            if np.sum(policy[i, :]) == 0:
                ind_max_quality = np.nonzero(channel_qualities[i, :] == np.max(channel_qualities[i, :]))[0]
                policy[i, ind_max_quality] = 1

        return policy

    def sStrongestConfigurationsPolicy(self, channel_qualities, k=2):
        
        '''
        s-Strongest-Configurations Access Policy (s-SCP).

        Parameters:
            channel_qualities: Matrix containing the channel qualities.
            k: Number of time slots selected by the contending MTDs. k=2 by default.

    Outputs:
            policy: Binary matrix with decisions taken by MTDs, where 1 denotes transmission and 0 denotes idle.
        '''

        _, num_time_slots = np.shape(channel_qualities)
        policy = np.zeros(np.shape(channel_qualities))

        maxk_values = np.partition(channel_qualities, num_time_slots-k, axis=1)[:,-k:]

        for kk in range(k):

            policy += (channel_qualities.T == maxk_values[:, kk].reshape(-1)).T
        
        return policy

    def slottedALOHAPolicy(self, num_cont_mtds, num_time_slots):
        
        '''
        Slotted ALOHA Policy (sALOHA).

        Parameters:
            num_cont_mtds: Number of contending MTDs.
            num_time_slots: Number of time slots.

    Outputs:
            policy: Binary matrix with decisions taken by MTDs, where 1 denotes transmission and 0 denotes idle.
        '''
        
        policy = np.random.uniform(low=0, high=1, size=(num_cont_mtds, num_time_slots)) < 1/num_time_slots

        for i in range(num_cont_mtds):
            
            if np.sum(policy[i, :]) == 0:
                
                policy[i, np.random.randint(low=0, high=num_time_slots)] = 1

        return policy

    def CRDSAPolicy(self, num_cont_mtds, num_time_slots):
        
        '''
        Contention Resolution Diversity Slotted ALOHA Access Policy (CRDSAP).

        Parameters:
            num_cont_mtds: Number of contending MTDs.
            num_time_slots: Number of time slots.

    Outputs:
            policy: Binary matrix with decisions taken by MTDs, where 1 denotes transmission and 0 denotes idle.
        '''

        if num_time_slots <=2:

            policy = np.ones(shape=(num_cont_mtds, num_time_slots))
            return policy

        policy = np.zeros(shape=(num_cont_mtds, num_time_slots))

        for i in range(num_cont_mtds):
            policy[i, np.random.permutation(num_time_slots)[:2]] = 1

        return policy

    def IRSAPolicy(self, num_cont_mtds, num_time_slots):
        
        '''
        Irregular Repetition Slotted ALOHA Access Policy (IRSAP).
        
        Parameters:
            num_cont_mtds: Number of contending MTDs.
            num_time_slots: Number of time slots.
        
    Outputs:
            policy: Binary matrix with decisions taken by MTDs, where 1 denotes transmission and 0 denotes idle.
        '''
        
        if num_time_slots <= 2:
            policy = np.ones((num_cont_mtds, num_time_slots))
            return policy

        base = np.arange(2, num_time_slots+1)

        prob_num_replicas = (1+1/(num_time_slots-1)) / ((base-1) * base)

        num_replicas = np.random.choice(base, num_cont_mtds, p=prob_num_replicas)

        policy = np.zeros((num_cont_mtds, num_time_slots), dtype=bool)

        for i in range(num_cont_mtds):
            
            policy[i, np.random.permutation(num_time_slots)[:num_replicas[i]]] = 1
        
        return policy

class MTDsClassifiers():
    
    def __init__(self):

        pass

    def findLocalizationThreshold(self, loc_coeffs):
        
        '''
        Estimates the optimal localization threshold of the system. Larger loc_coeffs arrays result in more precise estimations.

        Parameters:
            loc_coeffs: Array containing MTDs' estimated localization coefficicients.

        Outputs: The estimated optimal localization threshold. Deppending on loc_coeffs.size, results might be imprecise.
        '''
        
        loc_coeffs = np.sort(loc_coeffs)

        return loc_coeffs[loc_coeffs.size // 2]

    def classifyByChannelVariance(self, estimated_channel_coeffs, threshold, return_values=False):
        
        '''
        Classifies MTDs by computing the variance of the its normalized channel coefficients. The normalization is performed by this method.

        Parameters:
            estimated_channel_coeffs: Matrix containing the channel coefficients estimations.
            threshold               : Limiar applied to classify users.
            return_values           : If True, returns the values of the estimated localization coefficents. If False, returns only the indicators.

        Outputs:
            indicators   : Boolean vector of dimension np.shape(channel_coeffs)[0] (num_cont_mtds) containing the estimation made by the respective user.
                           If MTD k need RIS to perform uplink, returns 1, on the contrary returns 0 in the respective array position.
            estimated_uks: Estimated localization coefficients computed by each MTD. Only returned if return_values==True.
        '''

        #- Normalization of the channel coefficients:
        normalized_coeffs = estimated_channel_coeffs / np.mean(estimated_channel_coeffs, axis=1, keepdims=True)

        #- Computing the variances along the time slots axis:
        estimated_uks = np.var(normalized_coeffs, axis=1, ddof=1)

        #- Estimating positions:
        indicators = estimated_uks >= threshold

        if return_values:

            return indicators, estimated_uks
        
        return indicators

    def classifyByChannelQualities(self, estimated_channel_qualities, threshold, return_values=False):
        
        '''
        Classifies MTDs by computing the variance of the its normalized channel qualities. The normalization is performed by this method.

        Parameters:
            estimated_channel_coeffs: Matrix containing the channel coefficients estimations.
            threshold               : Limiar applied to classify users.
            return_values           : If True, returns the values of the estimated localization coefficents. If False, returns only the indicators.

        Outputs:
            indicators   : Boolean vector of dimension np.shape(channel_coeffs)[0] (num_cont_mtds) containing the estimation made by the respective user.
                           If MTD k need RIS to perform uplink, returns 1, on the contrary returns 0 in the respective array position.
            estimated_uks: Estimated localization coefficients computed by each MTD. Only returned if return_values==True.
        '''

        # Normalization:
        normalized_channel_qualities = estimated_channel_qualities / np.sum(estimated_channel_qualities, axis=1, keepdims=True)

        # Computing the variances along the time slots axis:
        estimated_uks = np.var(normalized_channel_qualities, axis=1, ddof=1)

        # Estimating positions:
        indicators = estimated_uks >= threshold

        if return_values:
            
            return indicators, estimated_uks
        
        return indicators

class SICReceiver():

    def __init__(self, scenario):

        assert isinstance(scenario, Scenario), "Verify if input 'scenario' is a Scenario Class."

        self.snr_threshold = scenario.sic_snr_threshold

    def decode(self, weights_matrix, return_snrs=False):
        
        '''
        Decode the packets transmitted by the contending MTDs.

        Parameters:
            weights_matrix: Matrix containing the SNRs of the signals transmitted by the contending MTDs
                            during the access time slots following the adopted access policy. In other words, weights_matrix = snrs*policy.
            return_snrs   : If True, retuns the SNRs of the slots where a packet was successfully decoded. Default is False.

        Outputs:
            sa_indicators: Array of successfull attempts indicator of MTDs. 1 means success and 0 means failure fot the respective MTD.
        '''

        (num_cont_mtds, _) = np.shape(weights_matrix)
        sa_indicators = np.zeros((num_cont_mtds), dtype=bool)
        
        if return_snrs:
            snrs = np.zeros((num_cont_mtds), dtype=float)

        # Find singletons:
        singletons = np.nonzero(np.sum(weights_matrix > 0, axis=0) == 1)[0]

        while np.size(singletons) > 0:
            # Select MTD node of the next singleton
            time_slot_node = singletons[0]
            mtd_node = np.nonzero(weights_matrix[:, time_slot_node] > 0)[0]

            # Compare SNR with the threshold:
            if weights_matrix[mtd_node, time_slot_node] >= self.snr_threshold:
                
                sa_indicators[mtd_node] = 1

                if return_snrs:
                    snrs[mtd_node] = weights_matrix[mtd_node, time_slot_node]

                weights_matrix[mtd_node, :] = 0

            else:
                weights_matrix[mtd_node, time_slot_node] = 0

            # Find singletons
            singletons = np.nonzero(np.sum(weights_matrix > 0, axis=0) == 1)[0]

        if return_snrs:
            
            return sa_indicators, snrs
        
        return sa_indicators

class Throughput():

    def __init__(self, scenario):

        assert isinstance(scenario, Scenario), "Verify if input 'scenario' is a Scenario Class."

        self.num_time_slots = scenario.num_time_slots
        self.access_slot_time = scenario.access_slot_time
        self.training_slot_time = scenario.training_slot_time
        self.sigma_slot_duration = scenario.sigma_slot_time

    def compute(self, num_sa, requires_training=True):
        
        '''
        Computes the system throughput.

        Parameters:
            num_sa           : Number of successful access attempts.
            requires_training: If True, the training step of the protocol is counted for Tf.
                               Otherwise, the training step is not considered in Tf.

        Outputs:
            throughput: The system throughput G, given in packets/s.
        '''

        if requires_training:
            
            throughput = num_sa / (self.num_time_slots*(self.training_slot_time + self.access_slot_time) + self.sigma_slot_duration)
        
        else:

            throughput = num_sa / (self.num_time_slots * self.access_slot_time)

        return throughput
  
class EnergyEfficiency():

    def __init__(self, scenario):

        assert isinstance(scenario, Scenario), "Verify if input 'scenario' is a Scenario Class."
        
        self.num_time_slots = scenario.num_time_slots

        self.bs_pa_ineff = scenario.bs_pa_ineff
        self.bs_tx_energy = scenario.bs_tx_energy
        self.bs_proc_power_density = scenario.bs_proc_power_density

        self.mtd_pa_ineff = scenario.mtd_pa_ineff
        self.mtd_tx_energy = scenario.mtd_tx_energy
        self.mtd_proc_power_density = scenario.mtd_proc_power_density

        self.ris_el_power_density = scenario.ris_el_power_density
        self.ris_num_els = scenario.ris_num_els

        self.access_slot_time = scenario.access_slot_time
        self.training_slot_time = scenario.training_slot_time
        self.sigma_slot_time = scenario.sigma_slot_time

    def computeSystemEE(self,
                        throughput,
                        num_tx_replicas,
                        num_cont_mtds,
                        policy_requires_training=True,
                        mtds_tx_energies=None,
                        return_devices_ee=True):
        '''
        Compute the system energy efficiency.

        Parameters:
            throughput              : The system throughput G, given in packets/s.
            num_tx_replicas         : Number of transmitted packet replicas send by each MTD. If the number of replicas send by a policy is not fixed,
                                      this must be an array containing how many replicas was sent by each MTD.
            num_cont_mtds           : Number of contending MTDs.
            policy_requires_training: If True, considers that the broadcast of pilots must be performed by the BS during training.
            mtds_tx_energies        : Transmit energy of MTDs. Must have the same size as num_tx_replicas.
            return_devices_ee       : If True, the MTDs' EE is also computed.

    Outputs:
            The system energy efficiency.
          '''
        
        #- Calculates the frame duration:
        if policy_requires_training:

            frame_duration = self.num_time_slots * (self.access_slot_time + self.training_slot_time) + self.sigma_slot_time
            bs_power = self.num_time_slots * self.bs_pa_ineff * (self.bs_tx_energy / self.training_slot_time) + self.bs_proc_power_density * frame_duration
        
        else:

            frame_duration = self.num_time_slots * self.access_slot_time
            bs_power = self.bs_proc_power_density * frame_duration

        if isinstance(num_tx_replicas, np.ndarray):

            #- This if must be performed for DAP-RARAP protocols, where MTDs transmits with different powers.
            
            assert num_tx_replicas.size == mtds_tx_energies.size, "Variables 'num_tx_replicas' and 'mtds_tx_power' must have the same size."

            mtds_tx_powers = mtds_tx_energies / self.access_slot_time

            mtds_power = np.sum(num_tx_replicas * mtds_tx_powers * self.mtd_pa_ineff) + num_cont_mtds * self.mtd_proc_power_density * frame_duration
        
        else:

            mtds_power = num_tx_replicas * (self.mtd_tx_energy / self.access_slot_time) * self.mtd_pa_ineff + num_cont_mtds * self.mtd_proc_power_density * frame_duration 

        ris_el_power = self.ris_el_power_density * frame_duration
        ris_power = self.ris_num_els * ris_el_power

        total_power = bs_power + ris_power + mtds_power

        total_ee = throughput / total_power

        if return_devices_ee:
            
            devices_ee = throughput / mtds_power

            return total_ee, devices_ee

        return total_ee

class Fairness():

    def __init__(self, scenario):
        
        assert isinstance(scenario, Scenario), "Verify if input 'scenario' is a Scenario Class."

        pass

    def jainFairness(self, snrs):

        decoded_mtds = snrs[snrs>0]

        se = np.log2(1+snrs)

        if decoded_mtds.size == 0:

            return -1

        return (np.sum(se)**2) / (np.size(se) * np.sum(se**2))

    def mcs_meanFairness(self, mcs_fairness):

        num_access_policies, _ = np.shape(mcs_fairness)

        mean_fairness = np.zeros(shape=num_access_policies)

        for i in range(num_access_policies):
            
            mean_fairness[i] = np.sum(mcs_fairness[i, mcs_fairness[i,:]!=-1]) / np.sum(mcs_fairness[i,:]!=-1)

        return mean_fairness