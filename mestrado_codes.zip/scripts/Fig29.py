import matplotlib.pyplot as plt
import numpy as np
from Classes import Scenario, Channel, MTDsClassifiers

#* Script to generate LocCoeff Threshold vs Xi graphs for DAP-RARAP Protocol.

#- Simulation Parameters -#
num_realizations = 4000
num_cont_mtds = 100
blockage_att_dB = np.arange(0, 74, 4)
#--------------------------#

#* Initialize the data vectors:
avg_loc_threshold = np.zeros(shape=blockage_att_dB.size, dtype=float)

#: First Loop - Varying the number of RIS Elements :#
for Xi_id, Xi in enumerate(blockage_att_dB):

    #* Class initialization:
    scenario = Scenario(blockage_att_dB=Xi)
    scenario.adjustSlotTimes(tdma_frame_duration=800e-6)

    channel = Channel(scenario)

    error_var = scenario.noise_power / (scenario.bs_tx_power * scenario.pilot_length)

    print(f"Simulation progress: Point {Xi_id+1:.0f} of {blockage_att_dB.size:.0f}...")

    mcs_loc_threshold_values = np.zeros(shape=num_realizations, dtype=float)

    #: Third Loop - Monte Carlo Simulation :#
    for n in range(num_realizations):

        channel_coeffs = channel.generateChannelCoefficients(num_cont_mtds)

        estimated_channel_coeffs = channel_coeffs + np.sqrt(error_var/2) * (np.random.randn(num_cont_mtds, scenario.num_time_slots) + 1j*np.random.randn(num_cont_mtds, scenario.num_time_slots))

        channel_qualities = np.abs(estimated_channel_coeffs)**2

        _, loc_coeffs = MTDsClassifiers().classifyByChannelQualities(estimated_channel_qualities=channel_qualities, threshold=1e-3, return_values=True)

        #* Saves the current Monte Carlo Realization
        mcs_loc_threshold_values[n] = np.median(loc_coeffs)

    avg_loc_threshold[Xi_id] = np.mean(mcs_loc_threshold_values)

    #* Checkpoints the simulation, saving the throughput vectors:
    np.save(file="data/Figure 29/DAP_avg_loc_threshold.npy", arr=avg_loc_threshold)

    np.save(file="data/Figure 14/DAP_avg_loc_threshold_Xi.npy", arr=avg_loc_threshold)