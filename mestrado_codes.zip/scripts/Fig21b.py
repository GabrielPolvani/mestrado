import matplotlib.pyplot as plt
import numpy as np
from Classes import Scenario, Channel, MTDsClassifiers

#* Script to generate MTDs percentage vs N graphs DAP-RARAP Protocol with a fixed localization threshold.

#- Simulation Parameters -#
num_realizations = 4000
num_cont_mtds = 14
num_ris_els_xz = np.arange(2, 26)
num_time_slots = np.array([20])

loc_threshold = 1e-3
#--------------------------#

#: First Loop: Goes through all values of Time Slots (S) :#
for S in num_time_slots:

    print(f"\n############### S = {S:.0f} ###############")

    #* Initialize the data vectors:
    avg_green_mtds = np.zeros(shape=num_ris_els_xz.size, dtype=float)
    avg_red_mtds = np.zeros(shape=num_ris_els_xz.size, dtype=float)

    #: Second Loop - Varying the number of RIS Elements :#
    for N_id, Nx in enumerate(num_ris_els_xz):

        #* Class initialization:
        scenario = Scenario(num_time_slots=S, ris_num_els_x=Nx, ris_num_els_z=Nx)
        scenario.adjustSlotTimes(tdma_frame_duration=800e-6)

        channel = Channel(scenario)

        error_var = scenario.noise_power / (scenario.bs_tx_power * scenario.pilot_length)

        print(f"Simulation progress: Point {N_id+1:.0f} of {num_ris_els_xz.size:.0f}...")

        mcs_green_mtds = np.zeros(shape=num_realizations, dtype=float)
        mcs_red_mtds = np.zeros(shape=num_realizations, dtype=float)

        #: Third Loop - Monte Carlo Simulation :#
        for n in range(num_realizations):

            channel_coeffs = channel.generateChannelCoefficients(num_cont_mtds)

            estimated_channel_coeffs = channel_coeffs + np.sqrt(error_var/2) * (np.random.randn(num_cont_mtds, S) + 1j*np.random.randn(num_cont_mtds, S))

            channel_qualities = np.abs(estimated_channel_coeffs)**2

            needRIS = MTDsClassifiers().classifyByChannelQualities(estimated_channel_qualities=channel_qualities, threshold=loc_threshold, return_values=False)

            mcs_green_mtds[n] = np.sum(~needRIS)
            mcs_red_mtds[n] = np.sum(needRIS)

        avg_green_mtds[N_id] = mcs_green_mtds.mean()
        avg_red_mtds[N_id] = mcs_red_mtds.mean()

        np.save(file="data/Figure 21/DAP_avg_green_mtds_"+str(S)+"_slots", arr=avg_green_mtds)
        np.save(file="data/Figure 21/DAP_avg_red_mtds_"+str(S)+"_slots", arr=avg_red_mtds)