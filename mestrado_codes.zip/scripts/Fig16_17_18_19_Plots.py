import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

fig1, ax1 = plt.subplots(ncols=1, nrows=1, figsize=(8.25, 7.92), layout="tight", subplot_kw={"projection":"3d"})
fig2, ax2 = plt.subplots(ncols=1, nrows=1, figsize=(8.25, 7.92), layout="tight", subplot_kw={"projection":"3d"})
fig3, ax3 = plt.subplots(ncols=1, nrows=1, figsize=(8.25, 7.92), layout="tight", subplot_kw={"projection":"3d"})
fig4, ax4 = plt.subplots(ncols=1, nrows=1, figsize=(8.25, 7.92), layout="tight", subplot_kw={"projection":"3d"})

fig5, ax5 = plt.subplots(ncols=1, nrows=1, figsize=(8.25, 7.92), layout="tight", subplot_kw={"projection":"3d"})
fig6, ax6 = plt.subplots(ncols=1, nrows=1, figsize=(8.25, 7.92), layout="tight", subplot_kw={"projection":"3d"})
fig7, ax7 = plt.subplots(ncols=1, nrows=1, figsize=(8.25, 7.92), layout="tight", subplot_kw={"projection":"3d"})
fig8, ax8 = plt.subplots(ncols=1, nrows=1, figsize=(8.25, 7.92), layout="tight", subplot_kw={"projection":"3d"})

fig9, ax9 = plt.subplots(ncols=1, nrows=1, figsize=(8.25, 7.92), layout="tight", subplot_kw={"projection":"3d"})
fig10, ax10 = plt.subplots(ncols=1, nrows=1, figsize=(8.25, 7.92), layout="tight", subplot_kw={"projection":"3d"})
fig11, ax11 = plt.subplots(ncols=1, nrows=1, figsize=(8.25, 7.92), layout="tight", subplot_kw={"projection":"3d"})
fig12, ax12 = plt.subplots(ncols=1, nrows=1, figsize=(8.25, 7.92), layout="tight", subplot_kw={"projection":"3d"})

fig13, ax13 = plt.subplots(ncols=1, nrows=1, figsize=(5.5, 5.28), layout="tight")
fig14, ax14 = plt.subplots(ncols=1, nrows=1, figsize=(5.5, 5.28), layout="tight")
fig15, ax15 = plt.subplots(ncols=1, nrows=1, figsize=(5.5, 5.28), layout="tight")

axes = [ax1, ax2, ax3, ax4, ax5, ax6, ax7, ax8, ax9, ax10, ax11, ax12]

DAP_t = np.load("data/Figure 16/DAP_throughput_values_20_slots.npy") / 1000
DAP_ee = np.load("data/Figure 17/DAP_total_ee_values_20_slots.npy") / 1000
DAP_mtds_ee = np.load("data/Figure 18/DAP_devices_ee_values_20_slots.npy") / 1000
mtds_power = 10*np.log10(np.load("data/Figure 16/DAP_mtds_tx_power.npy")/1e-3)
mtds_powers_SAP = 10*np.log10(np.load("data/Figure 19/SAP_mtds_tx_power.npy")/1e-3)
SAP_t = np.load("data/Figure 19/SAP_throughput_values_20_slots.npy") / 1000
SAP_ee = np.load("data/Figure 19/SAP_total_ee_values_20_slots.npy") / 1000
SAP_mtds_ee = np.load("data/Figure 19/SAP_devices_ee_values_20_slots.npy") / 1000

plot_colors = np.array(["#C31051", "#56A70A", "#E36709", "#0D39A6", "#8B4513", "#32CD32", "#1E90FF", "#800080"])
plot_ls = np.array(["-", "-", "-", "-"])
plot_lw = np.array([1.5, 1.5, 1.5, 1.5])
plot_markers = np.array(["s", "^", "o", "$*$"])
plot_labels = np.array(["IRSAP", "CRDSAP", "2-SCP", "CARP"])

autosave = True

for i in range(4):

    my_cmap = LinearSegmentedColormap.from_list('CustomRedGreen', ["#000000", plot_colors[i+4]])

    axes[i].plot_surface(*np.meshgrid(mtds_power,mtds_power), DAP_t[:,:,i], color=plot_colors[i+4], alpha=0.5, shade=True, cmap=my_cmap)
    axes[i+4].plot_surface(*np.meshgrid(mtds_power,mtds_power), DAP_ee[:,:,i], color=plot_colors[i+4], alpha=0.5, shade=True, cmap=my_cmap)
    axes[i+8].plot_surface(*np.meshgrid(mtds_power,mtds_power), DAP_mtds_ee[:,:,i], color=plot_colors[i+4], alpha=0.5, shade=True, cmap=my_cmap)

    axes[i].view_init(elev=30, azim=-130)
    axes[i+4].view_init(elev=30, azim=-130)
    axes[i+8].view_init(elev=30, azim=-130)

    max_t = np.max(DAP_t[:,:,i])
    max_ee = np.max(DAP_ee[:,:,i])
    max_mtds_ee = np.max(DAP_mtds_ee[:,:,i])

    t_y_points, t_x_points = np.where(DAP_t[:,:,i] >= 0.95*max_t)
    ee_y_point, ee_x_point = np.where(DAP_ee[:,:,i] == max_ee)
    mt_y_point, mt_x_point = np.where(DAP_mtds_ee[:,:,i] == max_mtds_ee)

    axes[i].plot([mtds_power[np.min(t_x_points)], mtds_power[np.min(t_x_points)]],
                 [-30, 50],
                 ls="--", color="000000", marker="o")
    
    axes[i].plot([-30, 50],
                 [mtds_power[np.min(t_y_points)], mtds_power[np.min(t_y_points)]],
                 ls="--", color="000000", marker="o")

    axes[i+4].plot([*mtds_power[ee_x_point], *mtds_power[ee_x_point], -30],
                   [-30, *mtds_power[ee_y_point], *mtds_power[ee_y_point]],
                   np.full(3, 0),
                   ls="--", color="000000", marker="o")
    
    axes[i+4].plot([*mtds_power[ee_x_point], *mtds_power[ee_x_point], *mtds_power[ee_x_point]],
                   [*mtds_power[ee_y_point], *mtds_power[ee_y_point], 50],
                   [0, max_ee, max_ee],
                   ls="--", color="000000", marker="o")

    axes[i+8].plot([*mtds_power[mt_x_point], *mtds_power[mt_x_point], -30],
                   [-30, *mtds_power[mt_y_point], *mtds_power[mt_y_point]],
                   np.full(3, 0),
                   ls="--", color="000000", marker="o")
    
    axes[i+8].plot([*mtds_power[mt_x_point], *mtds_power[mt_x_point], *mtds_power[mt_x_point]],
                   [*mtds_power[mt_y_point], *mtds_power[mt_y_point], 50],
                   [0, max_mtds_ee, max_mtds_ee],
                   ls="--", color="000000", marker="o")
    
    ax13.plot(mtds_powers_SAP, SAP_t[i,:], color=plot_colors[i], ls=plot_ls[i], marker=plot_markers[i], lw=plot_lw[i], mfc="#FFFFFF", mew=1.5, label=plot_labels[i], markevery=3)
    ax14.plot(mtds_powers_SAP, SAP_ee[i,:], color=plot_colors[i], ls=plot_ls[i], marker=plot_markers[i], lw=plot_lw[i], mfc="#FFFFFF", mew=1.5, label=plot_labels[i], markevery=3)
    ax15.plot(mtds_powers_SAP, SAP_mtds_ee[i,:], color=plot_colors[i], ls=plot_ls[i], marker=plot_markers[i], lw=plot_lw[i], mfc="#FFFFFF", mew=1.5, label=plot_labels[i], markevery=3)

for i in range(4):

    axes[i].set_xlim([np.min(mtds_power), np.max(mtds_power)])
    axes[i].set_ylim([np.min(mtds_power), np.max(mtds_power)])
    axes[i].set_zlim([0, 17])
    axes[i].set_xlabel("$\\rho_H$ [dBm]")
    axes[i].set_ylabel("$\\rho_L$ [dBm]")
    axes[i].set_zlabel("Throughput [k.packets/s]")

    axes[i+4].set_xlim([np.min(mtds_power), np.max(mtds_power)])
    axes[i+4].set_ylim([np.min(mtds_power), np.max(mtds_power)])
    axes[i+4].set_zlim([0, 2.5])
    axes[i+4].set_xlabel("$\\rho_H$ [dBm]")
    axes[i+4].set_ylabel("$\\rho_L$ [dBm]")
    axes[i+4].set_zlabel("Total EE [k.packets/J ]")

    axes[i+8].set_xlim([np.min(mtds_power), np.max(mtds_power)])
    axes[i+8].set_ylim([np.min(mtds_power), np.max(mtds_power)])
    axes[i+8].set_zlim([0, 110])
    axes[i+8].set_xlabel("$\\rho_H$ [dBm]")
    axes[i+8].set_ylabel("$\\rho_L$ [dBm]")
    axes[i+8].set_zlabel("MTD's EE [k.packets/J ]")

ax13.set_xlim([np.min(mtds_powers_SAP), np.max(mtds_powers_SAP)])
ax13.set_ylim([0, 17])
ax13.set_xlabel("$\\rho_k$ [dBm]")
ax13.set_ylabel("Throughput [k.packets/s]")
ax13.set_box_aspect(1)
ax13.grid()
ax13.legend(fontsize=10, draggable=True, ncols=1, edgecolor="#000000", shadow=True)

ax14.set_xlim([np.min(mtds_powers_SAP), np.max(mtds_powers_SAP)])
ax14.set_ylim([0, 5])
ax14.set_xlabel("$\\rho_k$ [dBm]")
ax14.set_ylabel("Total EE [k.packets/J]")
ax14.set_box_aspect(1)
ax14.grid()
ax14.legend(fontsize=10, draggable=True, ncols=1, edgecolor="#000000", shadow=True)

ax15.set_xlim([np.min(mtds_powers_SAP), np.max(mtds_powers_SAP)])
ax15.set_ylim([0, 110])
ax15.set_xlabel("$\\rho_{MTD}$ [dBm]")
ax15.set_ylabel("MTD's EE [k.packets/J]")
ax15.set_box_aspect(1)
ax15.grid()
ax15.legend(fontsize=10, draggable=True, ncols=1, edgecolor="#000000", shadow=True)

if autosave:

    base_datapath = "results/Figure 16/"
    
    fig1.savefig(fname=base_datapath + "DAP_Throughput_IRSAP+2-SCP.pdf")
    fig2.savefig(fname=base_datapath + "DAP_Throughput_IRSAP+CARP.pdf")
    fig3.savefig(fname=base_datapath + "DAP_Throughput_CRDSAP+2-SCP.pdf")
    fig4.savefig(fname=base_datapath + "DAP_Throughput_CRDSAP+CARP.pdf")

    base_datapath = "results/Figure 17/"

    fig5.savefig(fname=base_datapath + "DAP_EE_IRSAP+2-SCP.pdf")
    fig6.savefig(fname=base_datapath + "DAP_EE_IRSAP+CARP.pdf")
    fig7.savefig(fname=base_datapath + "DAP_EE_CRDSAP+2-SCP.pdf")
    fig8.savefig(fname=base_datapath + "DAP_EE_CRDSAP+CARP.pdf")

    base_datapath = "results/Figure 18/"

    fig9.savefig(fname=base_datapath + "DAP_MTDs_EE_IRSAP+2-SCP.pdf")
    fig10.savefig(fname=base_datapath + "DAP_MTDs_EE_IRSAP+CARP.pdf")
    fig11.savefig(fname=base_datapath + "DAP_MTDs_EE_CRDSAP+2-SCP.pdf")
    fig12.savefig(fname=base_datapath + "DAP_MTDs_EE_CRDSAP+CARP.pdf")

    base_datapath = "results/Figure 19/"

    fig13.savefig(fname=base_datapath + "SAP_Throughput.pdf")
    fig14.savefig(fname=base_datapath + "SAP_EE.pdf")
    fig15.savefig(fname=base_datapath + "SAP_MTDs_EE.pdf")