import matplotlib.pyplot as plt
import numpy as np
from Classes import Scenario, Channel, AccessPolicy, Throughput, SICReceiver, EnergyEfficiency, MTDsClassifiers

#* Script to generate Throughput/EE vs Xi graphs for DAP-RARAP Protocol.
#* Adopted Access Polices: IRSAP + 2-SCP, IRSAP + CARP, CRDSAP + 2-SCP and CRDSAP + CARP.

#- Simulation Parameters -#
num_realizations = 2000
num_cont_mtds = 14
blockage_att_dB = np.arange(0, 74, 4)

avg_loc_thresholds = np.load(file="data/Figure 29/DAP_avg_loc_threshold.npy")
#--------------------------#

#* Initialize the data vectors:
avg_throughput = np.zeros(shape=(4,blockage_att_dB.size), dtype=float)
avg_total_ee = np.zeros(shape=(4,blockage_att_dB.size), dtype=float)
avg_devices_ee = np.zeros(shape=(4,blockage_att_dB.size), dtype=float)

#: First Loop - Varying the number of RIS Elements :#
for Xi_id, Xi in enumerate(blockage_att_dB):

    #* Class initialization:
    scenario = Scenario(blockage_att_dB=Xi)
    scenario.adjustSlotTimes(tdma_frame_duration=800e-6)

    channel = Channel(scenario)
    energy_eff = EnergyEfficiency(scenario)
    throughput = Throughput(scenario)
    receiver = SICReceiver(scenario)

    uplink_energy_levels = np.array([1e-3, 10e-3]) * scenario.access_slot_time
    error_var = scenario.noise_power / (scenario.bs_tx_power * scenario.pilot_length)

    print(f"Simulation progress: Point {Xi_id+1:.0f} of {blockage_att_dB.size:.0f}...")

    mcs_throughput_values = np.zeros(shape=(4,num_realizations), dtype=float)
    mcs_total_ee_values = np.zeros(shape=(4,num_realizations), dtype=float)
    mcs_device_ee_values = np.zeros(shape=(4,num_realizations), dtype=float)

    #: Second Loop - Monte Carlo Simulation :#
    for n in range(num_realizations):

        channel_coeffs = channel.generateChannelCoefficients(num_cont_mtds)

        estimated_channel_coeffs = channel_coeffs + np.sqrt(error_var/2) * (np.random.randn(num_cont_mtds, scenario.num_time_slots) + 1j*np.random.randn(num_cont_mtds, scenario.num_time_slots))

        channel_qualities = np.abs(estimated_channel_coeffs)**2

        needRIS = MTDsClassifiers().classifyByChannelQualities(estimated_channel_qualities=channel_qualities, threshold=avg_loc_thresholds[Xi_id], return_values=False)

        #* Knowing if they need RIS assistance or not, MTDs can adjust their uplink energies:
        mtds_uplink_energies = np.full(shape=needRIS.shape, fill_value=uplink_energy_levels[0])
        mtds_uplink_energies[needRIS] = uplink_energy_levels[1]

        mtds_uplink_powers1 = mtds_uplink_energies / scenario.access_slot_time

        snrs = channel_qualities * mtds_uplink_powers1.reshape(num_cont_mtds,1) / scenario.noise_power

        #* The following labels represents all combinations of studied policies:
        #* (0) IRSAP+2-SCP     (1) IRSAP+CARP      (2) CRDSAP+2-SCP     (3) CRDSAP+CARP
        for p in range(4):

            policy = np.zeros((num_cont_mtds, scenario.num_time_slots))

            #* IRSAP+2-SCP:
            if p == 0:

                policy[~needRIS, :] = AccessPolicy().IRSAPolicy(num_cont_mtds=np.sum(~needRIS), num_time_slots=scenario.num_time_slots)
                policy[needRIS, :] = AccessPolicy().sStrongestConfigurationsPolicy(channel_qualities=channel_qualities[needRIS, :], k=2)
                    
            #* IRSAP+CARP:
            elif p == 1:

                policy[~needRIS, :] = AccessPolicy().IRSAPolicy(num_cont_mtds=np.sum(~needRIS), num_time_slots=scenario.num_time_slots)
                policy[needRIS, :] = AccessPolicy().configurationAwareRandomPolicy(channel_qualities=channel_qualities[needRIS, :])

            #* CRDSAP+2-SCP:
            elif p == 2:
                        
                policy[~needRIS, :] = AccessPolicy().CRDSAPolicy(num_cont_mtds=np.sum(~needRIS), num_time_slots=scenario.num_time_slots)
                policy[needRIS, :] = AccessPolicy().sStrongestConfigurationsPolicy(channel_qualities=channel_qualities[needRIS, :], k=2)

            #* CRDSAP+CARP
            elif p == 3:

                policy[~needRIS, :] = AccessPolicy().CRDSAPolicy(num_cont_mtds=np.sum(~needRIS), num_time_slots=scenario.num_time_slots)
                policy[needRIS, :] = AccessPolicy().configurationAwareRandomPolicy(channel_qualities=channel_qualities[needRIS, :])

            #* When the smart power control is performed, we need to know how many packets each MTD transmitted.
            num_replicas = np.sum(policy, axis=1)

            weights_matrix = snrs * policy

            #* Decoding the signal with SIC:
            sa_indicators = receiver.decode(weights_matrix)

            num_sa = sa_indicators.sum()

            #* Saves the current Monte Carlo Realization
            mcs_throughput_values[p,n] = throughput.compute(num_sa, requires_training=True)
            mcs_total_ee_values[p,n], mcs_device_ee_values[p,n] = energy_eff.computeSystemEE(mcs_throughput_values[p,n], 
                                                                                             num_replicas, 
                                                                                             num_cont_mtds, 
                                                                                             mtds_tx_energies=mtds_uplink_energies)

    avg_throughput[:,Xi_id] = mcs_throughput_values.mean(axis=1)
    avg_total_ee[:,Xi_id] = mcs_total_ee_values.mean(axis=1)
    avg_devices_ee[:, Xi_id] = mcs_device_ee_values.mean(axis=1)

    #* Checkpoints the simulation, saving the throughput vectors:
    np.save(file="data/Figure 30/DAP_throughput_values.npy", arr=avg_throughput)
    np.save(file="data/Figure 30/DAP_total_ee_values.npy", arr=avg_total_ee)
    np.save(file="data/Figure 30/DAP_devices_ee_values.npy", arr=avg_devices_ee)
    np.save(file="data/Figure 30/blockage_att_dB.npy", arr=blockage_att_dB)