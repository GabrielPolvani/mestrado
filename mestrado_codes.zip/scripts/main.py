import matplotlib.pyplot as plt
# Select the figure to generate:

figure = 30
only_plots = False

print(f"Simulating Figure {figure:.0f}. Results will be automatically saved.")

if figure == 5:

    import Fig5

elif figure == 6:

    import Fig6

elif figure == 7:

    import Fig7

elif figure == 8:

    import Fig8

elif figure == 9:

    if only_plots: import Fig9_Plots
    else: import Fig9_SAP, Fig9_DAP, Fig9_Plots

elif figure == 10:

    import Fig10

elif figure == 11:

    if only_plots: import Fig11_Plots
    else: import Fig11_SAP, Fig11_DAP_Green, Fig11_DAP_Red, Fig11_Plots

elif figure == 12:

    if only_plots: import Fig12_Plots
    else: import Fig12_SAP, Fig12_DAP_Green, Fig12_DAP_Red, Fig12_Plots

elif figure == 13:

    import Fig13

elif figure == 14:

    pass

elif figure == 15:

    if only_plots: import Fig15_Plots
    else: import Fig15_SAP, Fig15_DAP, Fig15_Plots

elif figure in [16, 17, 18, 19]:

    if only_plots: import Fig16_17_18_19_Plots
    else: import Fig16_17_18, Fig19, Fig16_17_18_19_Plots

elif figure == 20:

    if only_plots: import Fig20_Plots
    else: import Fig20_SAP, Fig20_DAP, Fig20_Plots

elif figure == 21:

    if only_plots: import Fig21_Plots
    else: import Fig21a, Fig21b, Fig21_Plots

elif figure == 22:

    if only_plots: import Fig22_Plots
    else: import Fig22, Fig22_Plots

elif figure == 23:

    if only_plots: import Fig23_Plots
    else: import Fig23, Fig23_Plots

elif figure == 24:

    if only_plots: import Fig24_Plots
    else: import Fig24_SAP, Fig24_DAP, Fig24_Plots

elif figure == 25:

    if only_plots: import Fig25_Plots
    else: import Fig25_SAP, Fig25_DAP, Fig25_Plots

elif figure == 26:

    if only_plots: import Fig26_Plots
    else: import Fig26_SAP, Fig26_DAP, Fig26_Plots

elif figure == 27:

    if only_plots: import Fig27_Plots
    else: import Fig27, Fig27_Plots

elif figure == 28:

    if only_plots: import Fig28_Plots
    else: import Fig28, Fig28_Plots

elif figure == 29:

    if only_plots: import Fig29_Plots
    else: import Fig29, Fig29_Plots

elif figure == 30:

    if only_plots: import Fig30_Plots
    else: import Fig30_SAP, Fig30_DAP, Fig30_Plots

print("Done.")
plt.show()