import matplotlib.pyplot as plt
import numpy as np

#* Throughput Figures:
fig11, ax11 = plt.subplots(nrows=1, ncols=1, layout="tight", figsize=(5.5, 5.28))
fig11.canvas.manager.set_window_title("DAP Throughput as a Function of N with Optimals Loc Coeffs Thresholds")

fig12, ax12 = plt.subplots(nrows=1, ncols=1, layout="tight", figsize=(5.5, 5.28))
fig12.canvas.manager.set_window_title("SAP x DAP Throughput Comparison as a Function of N with Optimals Loc Coeffs Thresholds")

#* Total Energy Efficiency Figures
fig21, ax21 = plt.subplots(nrows=1, ncols=1, layout="tight", figsize=(5.5, 5.28))
fig21.canvas.manager.set_window_title("DAP Total Energy Efficiency as a Function of N with Optimals Loc Coeffs Thresholds")

fig22, ax22 = plt.subplots(nrows=1, ncols=1, layout="tight", figsize=(5.5, 5.28))
fig22.canvas.manager.set_window_title("SAP x DAP Total Energy Efficiency Comparison as a Function of N with Optimals Loc Coeffs Thresholds")

#* Devices Energy Efficiency Figures
fig31, ax31 = plt.subplots(nrows=1, ncols=1, layout="tight", figsize=(5.5, 5.28))
fig31.canvas.manager.set_window_title("DAP MTDs Energy Efficiency as a Function of N with Optimals Loc Coeffs Thresholds")

fig32, ax32 = plt.subplots(nrows=1, ncols=1, layout="tight", figsize=(5.5, 5.28))
fig32.canvas.manager.set_window_title("SAP x DAP MTDs Energy Efficiency Comparison as a Function of N with Optimals Loc Coeffs Thresholds")

#- Plots Parameters -#
plot_colors = np.array(["#C31051", "#56A70A", "#E36709", "#0D39A6", "#8B4513", "#32CD32", "#1E90FF", "#800080"])
plot_ls = np.array(["-", ":", "--", "-."])
plot_markers = np.array(["s", "^", "o", "$*$", "v", "1", "x", "*"])
plot_labels = np.array(["IRSAP", "CRDSAP", "2-SCP", "CARP", "IRSAP+2-SCP", "IRSAP+CARP", "CRDSAP+2-SCP", "CRDSAP+CARP"])
#--------------------#

num_time_slots = np.array([20])

autosave = True

for S in num_time_slots:

    #: Loading the Data :#
    base_datapath = "data/Figure 22/"

    num_ris_els_xz = np.load(file=base_datapath + "num_ris_els_xz.npy")

    DAP_throughput = np.load(file=base_datapath + "DAP_throughput_values_"+str(S)+"_slots.npy") / 1000
    DAP_total_ee = np.load(file=base_datapath + "DAP_total_ee_values_"+str(S)+"_slots.npy") / 1000
    DAP_devices_ee = np.load(file=base_datapath + "DAP_devices_ee_values_"+str(S)+"_slots.npy") / 1000

    base_datapath = "data/Figure 20/"

    SAP_throughput = np.load(file=base_datapath + "SAP_throughput_values_"+str(S)+"_slots.npy") / 1000
    SAP_total_ee = np.load(file=base_datapath + "SAP_total_ee_values_"+str(S)+"_slots.npy") / 1000
    SAP_devices_ee = np.load(file=base_datapath + "SAP_devices_ee_values_"+str(S)+"_slots.npy") / 1000

    if S == num_time_slots[-1]:

        for i in range(4):

            ax11.plot(num_ris_els_xz**2, DAP_throughput[i,:], color=plot_colors[i+4], lw=1.5, ls=plot_ls[i], marker=plot_markers[i+4], mew=1.5, mfc="#FFFFFF", label=plot_labels[i+4], markevery=2)
            ax12.plot(num_ris_els_xz**2, np.max(SAP_throughput, axis=0), color="#000000", lw=.75, ls=":")
            ax12.plot(num_ris_els_xz**2, np.min(SAP_throughput, axis=0), color="#000000", lw=.75, ls=":")
            ax12.fill_between(num_ris_els_xz**2, np.min(SAP_throughput, axis=0), np.max(SAP_throughput, axis=0), color="#555555", alpha=0.1)
            ax12.plot(num_ris_els_xz**2, DAP_throughput[i,:], color=plot_colors[i+4], lw=1.5, ls=plot_ls[i], marker=plot_markers[i+4], mew=1.5, mfc="#FFFFFF", label=plot_labels[i+4], markevery=2)

            ax21.plot(num_ris_els_xz**2, DAP_total_ee[i,:], color=plot_colors[i+4], lw=1.5, ls=plot_ls[i], marker=plot_markers[i+4], mew=1.5, mfc="#FFFFFF", label=plot_labels[i+4], markevery=2)
            ax22.plot(num_ris_els_xz**2, np.max(SAP_total_ee, axis=0), color="#000000", lw=.75, ls=":")
            ax22.plot(num_ris_els_xz**2, np.min(SAP_total_ee, axis=0), color="#000000", lw=.75, ls=":")
            ax22.fill_between(num_ris_els_xz**2, np.min(SAP_total_ee, axis=0), np.max(SAP_total_ee, axis=0), color="#555555", alpha=0.1)
            ax22.plot(num_ris_els_xz**2, DAP_total_ee[i,:], color=plot_colors[i+4], lw=1.5, ls=plot_ls[i], marker=plot_markers[i+4], mew=1.5, mfc="#FFFFFF", label=plot_labels[i+4], markevery=2)

            ax31.plot(num_ris_els_xz**2, DAP_devices_ee[i,:], color=plot_colors[i+4], lw=1.5, ls=plot_ls[i], marker=plot_markers[i+4], mew=1.5, mfc="#FFFFFF", label=plot_labels[i+4], markevery=2)
            ax32.plot(num_ris_els_xz**2, np.max(SAP_devices_ee, axis=0), color="#000000", lw=.75, ls=":")
            ax32.plot(num_ris_els_xz**2, np.min(SAP_devices_ee, axis=0), color="#000000", lw=.75, ls=":")
            ax32.fill_between(num_ris_els_xz**2, np.min(SAP_devices_ee, axis=0), np.max(SAP_devices_ee, axis=0), color="#555555", alpha=0.1)
            ax32.plot(num_ris_els_xz**2, DAP_devices_ee[i,:], color=plot_colors[i+4], lw=1.5, ls=plot_ls[i], marker=plot_markers[i+4], mew=1.5, mfc="#FFFFFF", label=plot_labels[i+4], markevery=2)

ax11.set_xlabel("Number of RIS Elements (N)")
ax11.set_ylabel("Throughput [k.packets/s]")
ax11.grid()
ax11.legend(fontsize=10, draggable=True, ncols=1, edgecolor="#000000", shadow=True, loc="lower right")
ax11.set_xlim([np.min(num_ris_els_xz**2), np.max(num_ris_els_xz**2)])
ax11.set_ylim([-0.25, 14])
ax11.set_box_aspect(1)

ax12.set_xlabel("Number of RIS Elements (N)")
ax12.set_ylabel("Throughput [k.packets/s]")
ax12.grid()
ax12.legend(fontsize=10, draggable=True, ncols=1, edgecolor="#000000", shadow=True, loc="lower right")
ax12.set_xlim([np.min(num_ris_els_xz**2), np.max(num_ris_els_xz**2)])
ax12.set_ylim([-0.25, 14])
ax12.set_box_aspect(1)

ax21.set_xlabel("Number of RIS Elements (N)")
ax21.set_ylabel("Total Energy Efficiency [k.packets/J]")
ax21.grid()
ax21.legend(fontsize=10, draggable=True, ncols=1, edgecolor="#000000", shadow=True, loc="lower right")
ax21.set_xlim([np.min(num_ris_els_xz**2), np.max(num_ris_els_xz**2)])
ax21.set_ylim([-0.1, 5.0])
ax21.set_box_aspect(1)

ax22.set_xlabel("Number of RIS Elements (N)")
ax22.set_ylabel("Total Energy Efficiency [k.packets/J]")
ax22.grid()
ax22.legend(fontsize=10, draggable=True, ncols=1, edgecolor="#000000", shadow=True, loc="lower right")
ax22.set_xlim([np.min(num_ris_els_xz**2), np.max(num_ris_els_xz**2)])
ax22.set_ylim([-0.1, 5.0])
ax22.set_box_aspect(1)

ax31.set_xlabel("Number of RIS Elements (N)")
ax31.set_ylabel("Devices Energy Efficiency [k.packets/J]")
ax31.grid()
ax31.legend(fontsize=10, draggable=True, ncols=2, edgecolor="#000000", shadow=True, loc="lower right")
ax31.set_xlim([np.min(num_ris_els_xz**2), np.max(num_ris_els_xz**2)])
ax31.set_ylim([-1, 45])
ax31.set_box_aspect(1)

ax32.set_xlabel("Number of RIS Elements (N)")
ax32.set_ylabel("Devices Energy Efficiency [k.packets/J]")
ax32.grid()
ax32.legend(fontsize=10, draggable=True, ncols=2, edgecolor="#000000", shadow=True, loc="lower right")
ax32.set_xlim([np.min(num_ris_els_xz**2), np.max(num_ris_els_xz**2)])
ax32.set_ylim([-1, 45])
ax32.set_box_aspect(1)

if autosave:
    
    base_datapath = "results/Figure 22/"

    fig11.savefig(fname=base_datapath + "DAP_Throughput.pdf")
    fig12.savefig(fname=base_datapath + "SAP_DAP_Throughput.pdf")
    fig21.savefig(fname=base_datapath + "DAP_EE.pdf")
    fig22.savefig(fname=base_datapath + "SAP_DAP_EE.pdf")
    fig31.savefig(fname=base_datapath + "DAP_EE_MTDS.pdf")
    fig32.savefig(fname=base_datapath + "SAP_DAP_EE_MTDS.pdf")