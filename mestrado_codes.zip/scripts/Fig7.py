import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from Classes import Scenario, Channel, AccessPolicy

colors = ["#FFFFFF", "#1F73E0", "#3212E0"]
cmap = LinearSegmentedColormap.from_list("X", colors)

fig1, ax1 = plt.subplots(nrows=1, ncols=1, layout="tight", figsize=(5.5, 5.28), subplot_kw={"projection":"polar"})
fig1.canvas.manager.set_window_title("Scenario and MTDs Positions")

fig2, ax2 = plt.subplots(nrows=1, ncols=1, layout="tight", figsize=(5.5, 5.28))
fig2.canvas.manager.set_window_title("Average SNRs")

scenario = Scenario()
channel = Channel(scenario)
access_policy = AccessPolicy()
error_var = scenario.noise_power / (scenario.bs_tx_power * scenario.pilot_length)

num_realizations = 10000

num_cont_mtds = 20

mtds_angles = np.tile(np.linspace(5*np.pi/180, np.pi-5*np.pi/180, num_cont_mtds//2, endpoint=True), 2)
mtds_dists = np.concatenate([np.full(num_cont_mtds//2, scenario.mtd_dist_range[0]+10), np.full(num_cont_mtds//2, scenario.mtd_dist_range[1]-10)])

scenario.plot(num_cont_mtds=num_cont_mtds, angle_data=mtds_angles, dist_data=mtds_dists, axis=ax1)

snrs = np.zeros((num_cont_mtds, scenario.num_time_slots), dtype=float)

for n in range(num_realizations):

    channel_coeffs = channel.generateChannelCoefficients(num_cont_mtds=num_cont_mtds, random_upos=False, mtds_angles=mtds_angles, mtds_dists=mtds_dists, riccian_factors=(1e10, 1e10, 1e10))
    channel_coeffs += np.sqrt(error_var/2) * (np.random.randn(num_cont_mtds, scenario.num_time_slots) + 1j*np.random.randn(num_cont_mtds, scenario.num_time_slots))

    channel_qualities = np.abs(channel_coeffs)**2
    snrs += 10*np.log10(scenario.mtd_tx_power * channel_qualities / scenario.noise_power)

for k in range(num_cont_mtds//2):
    ax1.text(mtds_angles[k], mtds_dists[k]+10, str(k+1), ha="center", va="center")
    ax1.text(mtds_angles[k+10], mtds_dists[k+10]-10, str(k+11), ha="center", va="center")

ax1.set_xlim([0, np.pi])
ax1.set_ylim([0, scenario.mtd_dist_range[1] + 5])
ax1.legend(ncols=4, draggable=True, shadow=True, edgecolor="#000000", loc="lower center")

axis2 = ax2.imshow(snrs/num_realizations, cmap=cmap)
fig2.colorbar(axis2, ax=ax2, shrink=0.75, label="SNR [dB]")
ax2.set_xticks(np.arange(1, scenario.num_time_slots+1)-0.5, labels=[str(i) for i in range(1, scenario.num_time_slots+1,1)], ha="right")
ax2.set_yticks(np.arange(1, num_cont_mtds+1)-0.5, labels=[str(i) for i in range(1, num_cont_mtds+1,1)], va="bottom")
ax2.grid(which="major", lw=0.25, color="#000000")

ax2.set_xlabel("Access slot indice")
ax2.set_ylabel("MTD indice")

fig1.savefig("results/Figure 7/Scenario.pdf")
fig2.savefig("results/Figure 7/Average_SNRs.pdf")