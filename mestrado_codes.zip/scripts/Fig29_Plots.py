import matplotlib.pyplot as plt
import numpy as np

#* Script to plot Throughput/EE vs K graphs.
#* Adopted Access Polices: IRSAP, CRDSAP, 2-SCP and CARP.

#* Optimal Loc Thresholds Plot as a Function of Xi
fig, ax = plt.subplots(nrows=1, ncols=1, layout="tight", figsize=(5.5, 5.28))
fig.canvas.manager.set_window_title("Optimal Localization Coeffs as a Function of Blockage Attenuation")

#- Plots Parameters -#
plot_colors = np.array(["#C31051", "#56A70A", "#E36709", "#0D39A6", "#8B4513", "#32CD32", "#1E90FF", "#800080"])
plot_ls = np.array(["-", ":", "--", "-."])
plot_markers = np.array(["s", "^", "o", "$*$", "v", "1", "x", "*"])
plot_labels = np.array(["IRSAP", "CRDSAP", "2-SCP", "CARP", "IRSAP+2-SCP", "IRSAP+CARP", "CRDSAP+2-SCP", "CRDSAP+CARP"])
#--------------------#

base_datapath = "data/Figure 29/"

autosave = True

#: Loading the Data :#
blockage_att_dB = np.arange(0, 74, 4)
avg_loc_threshold = np.load(file=base_datapath + "DAP_avg_loc_threshold.npy")

ax.semilogy(blockage_att_dB, avg_loc_threshold, color="#000000", marker="x", lw=2, markevery=2)

ax.set_xlabel("Blockage Attenuation ($\\xi$) [dB]")
ax.set_ylabel("Optimal Localization Threshold $(\\sigma_{th}^2)$")
ax.grid()
ax.set_xlim([np.min(blockage_att_dB), 70])
ax.set_ylim([1e-4, 1e-2])
ax.set_yticks([5e-4, 1e-3, 5e-3])
ax.set_box_aspect(1)

if autosave:
    
    base_datapath = "results/Figure 29/"

    fig.savefig(fname= base_datapath + "Optimal_Loc_Thresholds.pdf")