import matplotlib.pyplot as plt
import numpy as np

#* Script to plot Throughput/EE vs N graphs.

fig1, ax1 = plt.subplots(nrows=1, ncols=1, layout="tight", figsize=(5.5, 5.28))
fig1.canvas.manager.set_window_title("Optimal Loc Coeff as a Function of N")

#* Percentage of Green MTDs and Red MTDs Figure:
fig2, ax2 = plt.subplots(nrows=1, ncols=1, layout="tight", figsize=(5.5, 5.28))
fig2.canvas.manager.set_window_title("MTDs Percentage as a Function of N")

base_datapath = "data/Figure 21/"

autosave = True

opt_loc_coeff = np.load(file=base_datapath+"DAP_avg_loc_threshold_20_slots.npy")
num_ris_els_xz = np.load(file=base_datapath + "num_ris_els_xz.npy")

red_mtds = np.load(base_datapath + "DAP_avg_red_MTDs_20_slots.npy") * 100 / 14
green_mtds = np.load(base_datapath + "DAP_avg_green_MTDs_20_slots.npy") * 100 / 14

ax1.plot(num_ris_els_xz**2, opt_loc_coeff, color="#000000", marker="x", lw=1.5, ls="-")

ax2.plot(num_ris_els_xz**2, green_mtds, color="#1ABD4B", lw=2, ls="--", marker="1", mew=1.5, mfc="#FFFFFF", label="Green MTDs")
ax2.plot(num_ris_els_xz**2, red_mtds, color="#BC1318", lw=2, ls="-", marker="o", mew=1.5, mfc="#FFFFFF", label="Red MTDs")

ax1.set_xlabel("Number of RIS Elements (N)")
ax1.set_ylabel("Optimal Localization Threshold $(\\sigma_{th}^2)$")
ax1.grid()
ax1.set_xlim([np.min(num_ris_els_xz**2), np.max(num_ris_els_xz**2)])
ax1.set_box_aspect(1)

ax2.set_xlabel("Number of RIS Elements (N)")
ax2.set_ylabel("Percentage of MTDs (%)")
ax2.grid()
ax2.legend(fontsize=10, draggable=True, edgecolor="#000000", shadow=True, loc="lower right")
ax2.set_xlim([np.min(num_ris_els_xz**2), np.max(num_ris_els_xz**2)])
ax2.set_ylim([0, 100])
ax2.set_yticks([0, 25, 50, 75, 100])
ax2.set_yticklabels([0, 25, 50, 75, 100])
ax2.set_box_aspect(1)

if autosave:
    
    base_datapath = "results/Figure 21/"

    fig1.savefig(fname=base_datapath + "Optimal_Loc_Thresholds.pdf")
    fig2.savefig(fname=base_datapath + "MTDs_Percentage.pdf")

    base_datapath = "results/Figure 14/"
    fig1.savefig(fname=base_datapath + "Optimal_Loc_Thresholds_N.pdf")