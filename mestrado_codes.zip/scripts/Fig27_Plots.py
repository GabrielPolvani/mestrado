import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

fig1, ax1 = plt.subplots(ncols=1, nrows=1, figsize=(8.25, 7.92), layout="tight", subplot_kw={"projection":"3d"})
fig2, ax2 = plt.subplots(ncols=1, nrows=1, figsize=(8.25, 7.92), layout="tight", subplot_kw={"projection":"3d"})
fig3, ax3 = plt.subplots(ncols=1, nrows=1, figsize=(8.25, 7.92), layout="tight", subplot_kw={"projection":"3d"})
fig4, ax4 = plt.subplots(ncols=1, nrows=1, figsize=(8.25, 7.92), layout="tight", subplot_kw={"projection":"3d"})

axes = [ax1, ax2, ax3, ax4]

base_datapath = "data/Figure 27/"

DAP_f = np.load(base_datapath+"DAP_fairness_values_20_slots.npy")
mtds_powers = 10*np.log10(np.load(base_datapath+"DAP_mtds_tx_power.npy")/1e-3)

#- Plots Parameters -#
plot_colors = np.array(["#C31051", "#56A70A", "#E36709", "#0D39A6", "#8B4513", "#32CD32", "#1E90FF", "#800080"])
plot_ls = np.array(["-", "-", "-", "-"])
plot_lw = np.array([1.5, 1.5, 1.5, 1.5])
plot_markers = np.array(["s", "^", "o", "$*$"])
plot_labels = np.array(["IRSAP", "CRDSAP", "s-SCP", "CARP"])
#--------------------#

autosave = True

for i in range(4):

    my_cmap = LinearSegmentedColormap.from_list('CustomRedGreen', ["#000000", plot_colors[i+4]])

    axes[i].plot_surface(*np.meshgrid(mtds_powers,mtds_powers), DAP_f[:,:,i], color=plot_colors[i+4], alpha=0.5, shade=True, cmap=my_cmap)

    axes[i].view_init(elev=30, azim=-130)

for i in range(4):

    axes[i].set_xlim([np.min(mtds_powers), np.max(mtds_powers)])
    axes[i].set_ylim([np.min(mtds_powers), np.max(mtds_powers)])
    axes[i].set_zlim([0, 1])
    axes[i].set_xlabel("$\\rho_H$ [dBm]")
    axes[i].set_ylabel("$\\rho_L$ [dBm]")
    axes[i].set_zlabel("Jain's Fairness Index")

if autosave:

    base_datapath = "results/Figure 27/"
    
    fig1.savefig(fname=base_datapath + "DAP_Fairness_IRSAP+2-SCP.pdf")
    fig2.savefig(fname=base_datapath + "DAP_Fairness_IRSAP+CARP.pdf")
    fig3.savefig(fname=base_datapath + "DAP_Fairness_CRDSAP+2-SCP.pdf")
    fig4.savefig(fname=base_datapath + "DAP_Fairness_CRDSAP+CARP.pdf")