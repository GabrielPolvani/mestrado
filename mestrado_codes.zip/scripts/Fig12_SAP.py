import matplotlib.pyplot as plt
import numpy as np
from Classes import Scenario, Channel, AccessPolicy, SICReceiver, EnergyEfficiency

#* Script to generate SE vs MTDs Uplink Power graphs for SAP-RARAP Protocol.

#- Simulation Parameters -#
num_realizations = 2000
num_cont_mtds = 10
num_time_slots = np.array([20])
mtds_tx_powers = np.logspace(start=-9, stop=2, num=35)
#--------------------------#

#: First Loop: Goes through all values of Time Slots (S) :#
for S in num_time_slots:

    print(f"############### S = {S:.0f} ###############")

    #* Initialize the data vectors:
    avg_se = np.zeros(shape=(4,mtds_tx_powers.size), dtype=float)

    #: Second Loop - Varying the number of contending MTDs :#
    for p_id, p in enumerate(mtds_tx_powers):

        print(f"Simulation progress: Point {p_id+1:.0f} of {mtds_tx_powers.size:.0f}...")

        #* Class initialization:
        scenario = Scenario(mtd_tx_power=p)
        scenario.adjustSlotTimes(800e-6)

        channel = Channel(scenario)
        receiver = SICReceiver(scenario)
        energy_eff = EnergyEfficiency(scenario)

        error_var = scenario.noise_power / (scenario.bs_tx_power * scenario.pilot_length)

        mcs_se_values = np.zeros(shape=(4,num_realizations), dtype=float)

        #: Third Loop - Monte Carlo Simulation :#
        for n in range(num_realizations):

            channel_coeffs = channel.generateChannelCoefficients(num_cont_mtds)

            estimated_channel_coeffs = channel_coeffs + np.sqrt(error_var/2) * (np.random.randn(num_cont_mtds, S) + 1j*np.random.randn(num_cont_mtds, S))

            channel_qualities = np.abs(estimated_channel_coeffs)**2

            snrs = channel_qualities * scenario.mtd_tx_power / scenario.noise_power

            #* The following labels represents all studied policies:
            #* (0) IRSAP     (1) CRDSAP      (2) 2-SCP     (3) CARP
            for p in range(4):

                policy = np.zeros((num_cont_mtds,S))

                #* IRSAP:
                if p == 0:

                    policy = AccessPolicy().IRSAPolicy(num_cont_mtds=num_cont_mtds, num_time_slots=S)
                    
                #* CRDSAP:
                elif p == 1:

                    policy = AccessPolicy().CRDSAPolicy(num_cont_mtds=num_cont_mtds, num_time_slots=S)

                #* 2-SCP:
                elif p == 2:
                        
                    policy = AccessPolicy().sStrongestConfigurationsPolicy(channel_qualities=channel_qualities, k=2)

                #* CARP
                elif p == 3:

                    policy = AccessPolicy().configurationAwareRandomPolicy(channel_qualities=channel_qualities)

                num_replicas = np.sum(policy.sum())

                weigths_matrix = snrs * policy

                #* Decoding the signal with SIC:
                sa_indicators, decoded_snrs = receiver.decode(weigths_matrix, return_snrs=True)

                #* Saves the current Monte Carlo Realization
                mcs_se_values[p,n] = np.sum(sa_indicators*scenario.access_slot_time/scenario.tdma_frame_duration*np.log2(1+decoded_snrs))

        avg_se[:,p_id] = mcs_se_values.mean(axis=1)

        #* Checkpoints the simulation, saving the throughput vectors:
        np.save(file="data/Figure 12/SAP_se_values_"+str(S)+"_slots.npy", arr=avg_se)
        np.save(file="data/Figure 12/mtds_tx_powers.npy", arr=mtds_tx_powers)