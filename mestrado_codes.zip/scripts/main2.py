import matplotlib.pyplot as plt

# Generates the data for all Figures.

for i in range(1, 31):

    print(f"Generating Figure {i:.0f}")
    
    if i == 5:

        import Fig5

    elif i == 6:

        import Fig6

    elif i == 7:

        import Fig7

    elif i == 8:

        import Fig8

    elif i == 9:

        import Fig9_SAP, Fig9_DAP

    elif i == 10:

        import Fig10

    elif i == 11:

        import Fig11_SAP, Fig11_DAP_Green, Fig11_DAP_Red

    elif i == 12:

        import Fig12_SAP, Fig12_DAP_Green, Fig12_DAP_Red

    elif i == 13:

        import Fig13

    elif i == 14:

        import Fig21a, Fig23, Fig29

    elif i == 15:

        import Fig15_SAP, Fig15_DAP

    elif i == 16:

        import Fig16_17_18, Fig19
    
    elif i in [17, 18, 19]:

        pass

    elif i == 20:

        import Fig20_SAP, Fig20_DAP

    elif i == 21:

        import Fig21b

    elif i == 22:

        import Fig22

    elif i == 23:

        pass

    elif i == 24:

        import Fig24_SAP, Fig24_DAP

    elif i == 25:

        import Fig25_SAP, Fig25_DAP

    elif i == 26:

        import Fig26_SAP, Fig26_DAP

    elif i == 27:

        import Fig27

    elif i == 28:

        import Fig28

    elif i == 29:

        pass

    elif i == 30:

        import Fig30_SAP, Fig30_DAP

    else: pass

import Fig9_Plots, Fig11_Plots, Fig12_Plots, Fig15_Plots, Fig16_17_18_19_Plots, Fig20_Plots, Fig21_Plots, Fig22_Plots, Fig23_Plots, Fig24_Plots, Fig25_Plots, Fig26_Plots, Fig27_Plots, Fig28_Plots, Fig29_Plots, Fig30_Plots

print("Done.")
plt.show()