import matplotlib.pyplot as plt
import numpy as np
from Classes import Scenario, Channel, MTDsClassifiers

#* Script to generate LocCoeff Threshold vs S graphs for DAP-RARAP Protocol.

#- Simulation Parameters -#
num_realizations = 4000
num_cont_mtds = 100
num_time_slots = np.arange(2, 41, 1)
#--------------------------#

#* Initialize the data vectors:
avg_loc_threshold = np.zeros(shape=num_time_slots.size, dtype=float)

#: First Loop - Varying the number of RIS Elements :#
for S_id, S in enumerate(num_time_slots):

    #* Class initialization:
    scenario = Scenario(num_time_slots=S)
    scenario.adjustSlotTimes(tdma_frame_duration=800e-6)

    channel = Channel(scenario)

    error_var = scenario.noise_power / (scenario.bs_tx_power * scenario.pilot_length)

    print(f"Simulation progress: Point {S_id+1:.0f} of {num_time_slots.size:.0f}...")

    mcs_loc_threshold_values = np.zeros(shape=num_realizations, dtype=float)

    #: Third Loop - Monte Carlo Simulation :#
    for n in range(num_realizations):

        channel_coeffs = channel.generateChannelCoefficients(num_cont_mtds)

        estimated_channel_coeffs = channel_coeffs + np.sqrt(error_var/2) * (np.random.randn(num_cont_mtds, S) + 1j*np.random.randn(num_cont_mtds, S))

        channel_qualities = np.abs(estimated_channel_coeffs)**2

        _, loc_coeffs = MTDsClassifiers().classifyByChannelQualities(estimated_channel_qualities=channel_qualities, threshold=1e-3, return_values=True)

        #* Saves the current Monte Carlo Realization
        mcs_loc_threshold_values[n] = np.median(loc_coeffs)

    avg_loc_threshold[S_id] = np.mean(mcs_loc_threshold_values)

    #* Checkpoints the simulation, saving the throughput vectors:
    np.save(file="data/Figure 23/DAP_avg_loc_threshold.npy", arr=avg_loc_threshold)
    np.save(file="data/Figure 14/DAP_avg_loc_threshold_S.npy", arr=avg_loc_threshold)