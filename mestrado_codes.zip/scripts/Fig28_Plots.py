import numpy as np
import matplotlib.pyplot as plt

fig1, ax1 = plt.subplots(ncols=1, nrows=1, figsize=(5.5, 5.28), layout="tight")

base_datapath = "data/Figure 28/"

mtds_powers = 10*np.log10(np.load(base_datapath+"mtds_tx_power.npy")/1e-3)
SAP_f = np.load(base_datapath+"SAP_fairness_values_20_slots.npy")

#- Plots Parameters -#
plot_colors = np.array(["#C31051", "#56A70A", "#E36709", "#0D39A6", "#8B4513", "#32CD32", "#1E90FF", "#800080"])
plot_ls = np.array(["-", "-", "-", "-"])
plot_lw = np.array([1.5, 1.5, 1.5, 1.5])
plot_markers = np.array(["s", "^", "o", "$*$"])
plot_labels = np.array(["IRSAP", "CRDSAP", "s-SCP", "CARP"])
#--------------------#

autosave = True

for i in range(4):
    
    ax1.plot(mtds_powers, SAP_f[i,:], color=plot_colors[i], ls=plot_ls[i], marker=plot_markers[i], lw=plot_lw[i], mfc="#FFFFFF", mew=1.5, label=plot_labels[i], markevery=3)
    
    max_f = np.max(SAP_f[i,:])
    f_x_points = np.where(SAP_f[i,:] >= 0.95*max_f)

ax1.set_xlim([np.min(mtds_powers), np.max(mtds_powers)])
ax1.set_ylim([0, 1])
ax1.set_xlabel("$\\rho_k$ [dBm]")
ax1.set_ylabel("Jain's Fairness Index")
ax1.set_box_aspect(1)
ax1.grid()
ax1.legend(fontsize=10, draggable=True, ncols=1, edgecolor="#000000", shadow=True)

if autosave:

    base_datapath = "results/Figure 28/"

    fig1.savefig(fname=base_datapath + "SAP_Fairness.pdf")