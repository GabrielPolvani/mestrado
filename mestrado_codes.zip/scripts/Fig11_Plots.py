import matplotlib.pyplot as plt
import numpy as np

#* Throughput Figures:
fig1, ax1 = plt.subplots(nrows=1, ncols=1, layout="tight", figsize=(5.5, 5.28))
fig1.canvas.manager.set_window_title("SAP Throughput as a Function of MTDs Uplink Power")

fig2, ax2 = plt.subplots(nrows=1, ncols=1, layout="tight", figsize=(5.5, 5.28))
fig2.canvas.manager.set_window_title("DAP Throughput as a Function of Green MTDs Uplink Power")

fig3, ax3 = plt.subplots(nrows=1, ncols=1, layout="tight", figsize=(5.5, 5.28))
fig3.canvas.manager.set_window_title("SAP x DAP Throughput Comparison as a Function of Red MTDs Uplink Power")

#- Plots Parameters -#
plot_colors = np.array(["#C31051", "#56A70A", "#E36709", "#0D39A6", "#8B4513", "#32CD32", "#1E90FF", "#800080"])
plot_ls = np.array(["-", ":", "--", "-."])
plot_markers = np.array(["s", "^", "o", "$*$", "v", "1", "x", "*"])
plot_labels = np.array(["IRSAP", "CRDSAP", "2-SCP", "CARP", "IRSAP+2-SCP", "IRSAP+CARP", "CRDSAP+2-SCP", "CRDSAP+CARP"])
#--------------------#

base_datapath = "data/Figure 11/"
num_time_slots = np.array([20])
autosave = True

for S in num_time_slots:

    #: Loading the Data :#
    mtds_tx_power = np.load(file=base_datapath + "mtds_tx_powers.npy")

    t_SAP = np.load(file=base_datapath + "SAP_throughput_values_"+str(S)+"_slots.npy") / 1000
    t_gDAP = np.load(file=base_datapath + "gDAP_throughput_values_"+str(S)+"_slots.npy") / 1000
    t_rDAP = np.load(file=base_datapath + "rDAP_throughput_values_"+str(S)+"_slots.npy") / 1000

    if S == num_time_slots[-1]:

        for i in range(4):

            ax1.semilogx(mtds_tx_power, t_SAP[i,:], color=plot_colors[i], lw=1.5, ls=plot_ls[i], marker=plot_markers[i], mew=1.5, mfc="#FFFFFF", label=plot_labels[i])
            ax2.semilogx(mtds_tx_power, t_gDAP[i,:], color=plot_colors[i+4], lw=1.5, ls=plot_ls[i], marker=plot_markers[i+4], mew=1.5, mfc="#FFFFFF", label=plot_labels[i+4])
            ax3.semilogx(mtds_tx_power, t_rDAP[i, :], color=plot_colors[i+4], lw=1.5, ls=plot_ls[i], marker=plot_markers[i+4], mew=1.5, mfc="#FFFFFF", label=plot_labels[i+4])
            
ax1.set_xlabel("MTDs Uplink Power [W]")
ax1.set_ylabel("Throughput [k.packets/s]")
ax1.grid()
ax1.legend(fontsize=10, draggable=True, ncols=1, edgecolor="#000000", shadow=True, loc="lower right")
ax1.set_xlim([np.min(mtds_tx_power), np.max(mtds_tx_power)])
ax1.set_ylim([-0.05, 15])
ax1.set_xlim([1e-8, 1e2])
ax1.set_box_aspect(1)

ax2.set_xlabel("Green Side MTDS Uplink Power [W]")
ax2.set_ylabel("Throughput [k.packets/s]")
ax2.grid()
ax2.legend(fontsize=10, draggable=True, ncols=1, edgecolor="#000000", shadow=True, loc="lower right")
ax2.set_xlim([np.min(mtds_tx_power), np.max(mtds_tx_power)])
ax2.set_ylim([-0.05, 15])
ax2.set_xlim([1e-8, 1e2])
ax2.set_box_aspect(1)

ax3.set_xlabel("Red Side MTDs Uplink Power [W]")
ax3.set_ylabel("Throughput [k.packets/s]")
ax3.grid()
ax3.legend(fontsize=10, draggable=True, ncols=1, edgecolor="#000000", shadow=True, loc="lower right")
ax3.set_xlim([np.min(mtds_tx_power), np.max(mtds_tx_power)])
ax3.set_ylim([-0.05, 15])
ax3.set_xlim([1e-8, 1e2])
ax3.set_box_aspect(1)

if autosave:

    base_datapath = "results/Figure 11/"
    fig1.savefig(fname=base_datapath + "SAP_Throughput.pdf")
    fig2.savefig(fname=base_datapath + "GreenDAP_Throughput.pdf")
    fig3.savefig(fname=base_datapath + "RedDAP_Throughput.pdf")