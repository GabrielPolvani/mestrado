import numpy as np
import matplotlib.pyplot as plt
from Classes import Scenario

fig, ax = plt.subplots(nrows=1, ncols=1, layout="tight", figsize=(13, 4))

scenario = Scenario()
scenario.adjustSlotTimes(800e-6)

bs_processing_power_density = np.logspace(-3, 6, 1000)
mtd_processing_power_density = np.logspace(-3, 6, 1000)

policies_avg_packets = np.array([3.7802, 2, 2, 1.3314])
plot_colors = np.array(["#C31051", "#56A70A", "#E36709", "#0D39A6"])
plot_lss = np.array(["-", "-", "--", "-"])
plot_lw = np.array([2, 2, 2, 2])
plot_markers = np.array(["s", "^", "o", "$*$"])
plot_labels = ["IRSAP", "CRDSAP", "s-SCP", "CARP"]

#- Policies that use CSI with SAP-RARAP or ALL DAP-RARAP Combinations:
bs_rf_power = scenario.num_time_slots*scenario.bs_pa_ineff*scenario.bs_tx_power
bs_proc_power = scenario.tdma_frame_duration*bs_processing_power_density

total_power = bs_rf_power + bs_proc_power

ax.semilogx(bs_processing_power_density, 100*bs_rf_power / total_power, label="BS Power", lw=2, color="#000000", marker="x", markevery=25)

required_proc_power = (scenario.num_time_slots*scenario.bs_pa_ineff*scenario.bs_tx_power*(1/0.70 - 1)) / (scenario.tdma_frame_duration)

for i in range(4):
    
    mtd_rf_power = policies_avg_packets[i]*scenario.mtd_pa_ineff*scenario.mtd_tx_power
    mtd_proc_power = scenario.tdma_frame_duration*mtd_processing_power_density

    total_power = mtd_rf_power + mtd_proc_power

    ax.semilogx(mtd_processing_power_density, 100*mtd_rf_power / total_power, label="MTD - "+plot_labels[i], lw=plot_lw[i], color=plot_colors[i], marker=plot_markers[i], markevery=25, ls=plot_lss[i], mfc="#FFFFFF", mew=2)
    
    required_proc_power = (policies_avg_packets[i]*scenario.mtd_pa_ineff*scenario.mtd_tx_power*(1/0.88 - 1)) / (scenario.tdma_frame_duration)

ax.legend(draggable=True, shadow=True, edgecolor="#000000", ncols=1, fontsize=12)
ax.grid()
ax.set_xlabel("Processing Power Density [W/s]")
ax.set_ylabel("Percentage of RF Power")
ax.set_xlim([np.min(mtd_processing_power_density), np.max(mtd_processing_power_density)])
ax.set_ylim([-0.5, 100.5])

fig.savefig(fname="results/Figure 10/RF_power_percentages.pdf")