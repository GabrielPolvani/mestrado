import matplotlib.pyplot as plt
import numpy as np
from Classes import Scenario, Channel, MTDsClassifiers

fig1, ax1 = plt.subplots(nrows=1, ncols=1, layout='tight', figsize=(5.5, 5.28))
fig2, ax2 = plt.subplots(nrows=1, ncols=1, layout='tight', figsize=(5.5, 5.28))
fig3, ax3 = plt.subplots(nrows=1, ncols=1, layout='tight', figsize=(5.5, 5.28))

num_mtds = 30000

rice_coeffs = [(0, 0, 0),(1e10, 1e10, 1e10), (3/7, 9/1, 6/4)]
plot_labels = ["nLoS", "LoS", "Riccian"]
plot_colors = ["#000000", "#E12B28", "#1134A8"]

scenario = Scenario()
error_var = scenario.noise_power / (scenario.bs_tx_power * scenario.pilot_length)
channel = Channel(scenario)

for i, r in enumerate(rice_coeffs):

    channel_coeffs = channel.generateChannelCoefficients(num_mtds, riccian_factors=r)

    estimated_channel_coeffs = channel_coeffs + np.sqrt(error_var/2) * (np.random.randn(num_mtds, scenario.num_time_slots) + 1j*np.random.randn(num_mtds, scenario.num_time_slots))

    channel_qualities = np.abs(estimated_channel_coeffs)**2

    channel_qualities_f = channel_qualities.flatten()

    snrs = 10*np.log10(channel_qualities_f * scenario.mtd_tx_power / scenario.noise_power)

    _, u = MTDsClassifiers().classifyByChannelQualities(estimated_channel_qualities=channel_qualities, threshold=0, return_values=True)

    loc_threshold = MTDsClassifiers().findLocalizationThreshold(u)

    n, bins = np.histogram(snrs, bins=250, density=True)

    hist_x_values = np.zeros_like(n)

    for j in range(bins.size-1):

        hist_x_values[j] = (bins[j] + bins[j+1]) / 2

    ax1.plot(hist_x_values, n, lw=2, label=plot_labels[i], color=plot_colors[i])
    ax2.plot(np.sort(snrs), np.arange(num_mtds*scenario.num_time_slots)/(num_mtds*scenario.num_time_slots), lw=2, label=plot_labels[i], color=plot_colors[i])
    ax3.semilogx(np.sort(u), np.arange(num_mtds)/(num_mtds), lw=2, label=plot_labels[i], color=plot_colors[i])

ax1.legend(draggable=True, shadow=True, edgecolor="#000000")
ax1.set_xlabel("SNR [dB]")
ax1.set_ylabel("PDF")
ax1.set_xlim([-40, 75])
ax1.grid()
ax1.set_box_aspect(1)

ax2.legend(draggable=True, shadow=True, edgecolor="#000000")
ax2.set_xlabel("SNR [dB]")
ax2.set_ylabel("CDF")
ax2.set_xlim([-40, 75])
ax2.grid()
ax2.set_box_aspect(1)

ax3.legend(draggable=True, shadow=True, edgecolor="#000000")
ax3.set_xlabel("Localization Coefficient ($\sigma^2_k$)")
ax3.set_ylabel("CDF")
ax3.grid()
ax3.set_box_aspect(1)

fig1.savefig(fname="results/Figure 13/Channel_SNR_PDF.pdf")
fig2.savefig(fname="results/Figure 13/Channel_SNR_CDF.pdf")
fig3.savefig(fname="results/Figure 13/Loc_Coeffs_CDF.pdf")