import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from Classes import Scenario, Channel, AccessPolicy

colors = ["#FFFFFF", "#1F73E0", "#3212E0"]
cmap = LinearSegmentedColormap.from_list("X", colors)

fig1, ax1 = plt.subplots(nrows=1, ncols=1, layout="tight", figsize=(5.5, 5.28))
fig1.canvas.manager.set_window_title("IRSAP Packets Distributions")

fig2, ax2 = plt.subplots(nrows=1, ncols=1, layout="tight", figsize=(5.5, 5.28))
fig2.canvas.manager.set_window_title("CRDSAP Packets Distributions")

fig3, ax3 = plt.subplots(nrows=1, ncols=1, layout="tight", figsize=(5.5, 5.28))
fig3.canvas.manager.set_window_title("s-SCP Packets Distributions")

fig4, ax4 = plt.subplots(nrows=1, ncols=1, layout="tight", figsize=(5.5, 5.28))
fig4.canvas.manager.set_window_title("CARP Packets Distributions")

axs = [ax1, ax2, ax3, ax4]
figs = [fig1, fig2, fig3, fig4]
file_names = ["IRSAP Packets Distributions", "CRDSAP Packets Distributions", "s-SCP Packets Distributions", "CARP Packets Distributions"]

scenario = Scenario()
channel = Channel(scenario)
access_policy = AccessPolicy()
error_var = scenario.noise_power / (scenario.bs_tx_power * scenario.pilot_length)

num_realizations = 10000

num_mtds = 20

mtds_angles = np.tile(np.linspace(5*np.pi/180, np.pi-5*np.pi/180, num_mtds//2, endpoint=True), 2)
mtds_dists = np.concatenate([np.full(num_mtds//2, scenario.mtd_dist_range[0]+10), np.full(num_mtds//2, scenario.mtd_dist_range[1]-10)])

# Letting MTDs select the access slot to uplink its packet for each access policy. We count the number of packets sent at each slot.

packets_count = np.zeros((num_mtds, scenario.num_time_slots, 4), dtype=float)
snrs = np.zeros((num_mtds, scenario.num_time_slots), dtype=float)

for n in range(num_realizations):

    channel_coeffs = channel.generateChannelCoefficients(num_cont_mtds=num_mtds, random_upos=False, mtds_angles=mtds_angles, mtds_dists=mtds_dists)
    channel_coeffs += np.sqrt(error_var/2) * (np.random.randn(num_mtds, scenario.num_time_slots) + 1j*np.random.randn(num_mtds, scenario.num_time_slots))

    channel_qualities = np.abs(channel_coeffs)**2

    for p in range(4):

        policy = np.zeros((num_mtds, scenario.num_time_slots))

        if p == 0: # IRSAP

            policy = access_policy.IRSAPolicy(num_mtds, scenario.num_time_slots)

        elif p == 1: # CRDSAP

            policy = access_policy.CRDSAPolicy(num_mtds, scenario.num_time_slots)

        elif p == 2: # s-SCP

            policy = access_policy.sStrongestConfigurationsPolicy(channel_qualities, k=2)

        elif p == 3: # CARP

            policy = access_policy.configurationAwareRandomPolicy(channel_qualities)

        packets_count[:,:,p] += policy

packets_probs = np.zeros_like(packets_count)

for p in range(4):

    packets_probs[:,:,p] = packets_count[:,:,p] / np.sum(packets_count[:,:,p], axis=1)

    a = axs[p].imshow(packets_probs[:,:,p], cmap=cmap, vmin=0, vmax=1)
    axs[p].set_xticks(np.arange(1, scenario.num_time_slots+1)-0.5, labels=[str(i) for i in range(1, scenario.num_time_slots+1,1)], ha="right")
    axs[p].set_yticks(np.arange(1, num_mtds+1)-0.5, labels=[str(i) for i in range(1, num_mtds+1,1)], va="bottom")
    axs[p].grid()
    axs[p].grid(which="major", lw=0.25, color="#000000")
    axs[p].set_xlabel("Access slot indice")
    axs[p].set_ylabel("MTD indice")

    figs[p].colorbar(a, ax=axs[p], shrink=0.75, label="Probability of Sending a Packet")
    figs[p].savefig(fname="results/Figure 8/"+file_names[p]+".pdf")