import matplotlib.pyplot as plt
import numpy as np

#* Script to generate LocCoeff Threshold vs S graphs for DAP-RARAP Protocol.

fig1, ax1 = plt.subplots(nrows=1, ncols=1, layout="tight", figsize=(5.5, 5.28))
fig1.canvas.manager.set_window_title("optimal Loc Threshold as a Function of S")

#* Loads the data:
avg_loc_threshold = np.load("data/Figure 23/DAP_avg_loc_threshold.npy")
num_time_slots = np.arange(2, 41, 1)

autosave = True
    
ax1.semilogy(num_time_slots, avg_loc_threshold, color="#000000", lw=2, ls="-", marker="2", mew=1.5, mfc="#FFFFFF")
ax1.set_xlabel("Number of Time Slots (S)")
ax1.set_ylabel("Optimal Localization Threshold")
ax1.grid()
ax1.set_xlim([np.min(num_time_slots), np.max(num_time_slots)])
ax1.set_box_aspect(1)

if autosave:

    fig1.savefig(fname="results/Figure 23/Optimal_Loc_Thresholds.pdf")
    fig1.savefig(fname="results/Figure 14/Optimal_Loc_Thresholds_S.pdf")