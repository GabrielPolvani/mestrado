import matplotlib.pyplot as plt
import numpy as np
from Classes import Scenario, Channel, AccessPolicy, Throughput, SICReceiver, MTDsClassifiers

#* Script to generate Throughput vs GREEN MTDs Uplink Power graphs for DAP-RARAP Protocol.
#* Adopted Access Polices: IRSAP + 2-SCP, IRSAP + CARP, CRDSAP + 2-SCP and CRDSAP + CARP.

#- Simulation Parameters -#
num_realizations = 2000
num_cont_mtds = 10
num_time_slots = np.array([20])
mtds_tx_powers = np.logspace(start=-9, stop=2, num=35) # Green MTDs Power
red_mtds_power = 10e-3 # Red MTDs Power

loc_threshold = 1e-3
#--------------------------#

#: First Loop: Goes through all values of Time Slots (S) :#
for S in num_time_slots:

    print(f"\n############### S = {S:.0f} ###############")
        
    #* Initialize the data vectors:
    avg_throughput = np.zeros(shape=(4,mtds_tx_powers.size), dtype=float)

    #: Second Loop - Varying the Uplink power of MTDs at the green side of the cell :#
    for p_id, p in enumerate(mtds_tx_powers):

        print(f"Simulation progress: Point {p_id+1:.0f} of {mtds_tx_powers.size:.0f}...")

        #* Class initialization:
        scenario = Scenario(mtd_tx_power=p)
        scenario.adjustSlotTimes(800e-6)

        channel = Channel(scenario)
        throughput = Throughput(scenario)
        receiver = SICReceiver(scenario)

        mcs_throughput_values = np.zeros(shape=(4,num_realizations), dtype=float)

        error_var = scenario.noise_power / (scenario.bs_tx_power * scenario.pilot_length)
        uplink_energy_levels = np.array([p, red_mtds_power]) * scenario.access_slot_time

        #: Third Loop - Monte Carlo Simulation :#
        for n in range(num_realizations):

            channel_coeffs = channel.generateChannelCoefficients(num_cont_mtds)

            estimated_channel_coeffs = channel_coeffs + np.sqrt(error_var/2) * (np.random.randn(num_cont_mtds, S) + 1j*np.random.randn(num_cont_mtds, S))

            channel_qualities = np.abs(estimated_channel_coeffs)**2

            needRIS = MTDsClassifiers().classifyByChannelQualities(estimated_channel_qualities=channel_qualities, threshold=loc_threshold, return_values=False)

            #* Knowing if they neet RIS assistance or not, MTDs can adjust their uplink power:
            mtds_uplink_energies = np.full(shape=needRIS.shape, fill_value=uplink_energy_levels[0])
            mtds_uplink_energies[needRIS] = uplink_energy_levels[1]

            mtds_uplink_powers = mtds_uplink_energies / scenario.access_slot_time

            snrs = channel_qualities * mtds_uplink_powers.reshape(num_cont_mtds,1) / scenario.noise_power

            #* The following labels represents all combinations of studied policies:
            #* (0) IRSAP+2-SCP     (1) IRSAP+CARP      (2) CRDSAP+2-SCP     (3) CRDSAP+CARP
            for p in range(4):

                policy = np.zeros((num_cont_mtds,S))

                #* IRSAP+2-SCP:
                if p == 0:

                    policy[~needRIS, :] = AccessPolicy().IRSAPolicy(num_cont_mtds=np.sum(~needRIS), num_time_slots=S)
                    policy[needRIS, :] = AccessPolicy().sStrongestConfigurationsPolicy(channel_qualities=channel_qualities[needRIS, :], k=2)
                        
                #* IRSAP+CARP:
                elif p == 1:

                    policy[~needRIS, :] = AccessPolicy().IRSAPolicy(num_cont_mtds=np.sum(~needRIS), num_time_slots=S)
                    policy[needRIS, :] = AccessPolicy().configurationAwareRandomPolicy(channel_qualities=channel_qualities[needRIS, :])

                #* CRDSAP+2-SCP:
                elif p == 2:
                            
                    policy[~needRIS, :] = AccessPolicy().CRDSAPolicy(num_cont_mtds=np.sum(~needRIS), num_time_slots=S)
                    policy[needRIS, :] = AccessPolicy().sStrongestConfigurationsPolicy(channel_qualities=channel_qualities[needRIS, :], k=2)

                #* CRDSAP+CARP
                elif p == 3:

                    policy[~needRIS, :] = AccessPolicy().CRDSAPolicy(num_cont_mtds=np.sum(~needRIS), num_time_slots=S)
                    policy[needRIS, :] = AccessPolicy().configurationAwareRandomPolicy(channel_qualities=channel_qualities[needRIS, :])

                #* When the smart power control is performed, we need to know how many packets each MTD transmitted.
                num_replicas = np.sum(policy, axis=1)

                weights_matrix = snrs * policy

                #* Decoding the signal with SIC:
                sa_indicators = receiver.decode(weights_matrix)

                num_sa = sa_indicators.sum()

                #* Saves the current Monte Carlo Realization
                mcs_throughput_values[p,n] = throughput.compute(num_sa)

        avg_throughput[:, p_id] = mcs_throughput_values.mean(axis=1)

        #* Checkpoints the simulation, saving the throughput vectors:
        np.save(file="data/Figure 11/gDAP_throughput_values_"+str(S)+"_slots", arr=avg_throughput)
        np.save(file="data/Figure 11/mtds_tx_powers", arr=mtds_tx_powers)