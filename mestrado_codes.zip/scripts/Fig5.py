import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.colorbar import ColorbarBase
from matplotlib.colors import Normalize
from Classes import Scenario, Channel

# Custom colormap:
colors = ["#222222", "#D40B0B", "#D4740B", "#D6C62D", "#0DBA55"]
my_cmap = LinearSegmentedColormap.from_list('CustomRedGreen', colors)

fig, ax = plt.subplots(nrows=1, ncols=1, figsize=(5.5, 5.28), layout="tight", subplot_kw={"projection":"polar"})

num_mtds = 1600
n_realizations = 10

scenario = Scenario(num_time_slots=10)
channel = Channel(scenario)

angles = np.linspace(scenario.mtd_angle_range[0], scenario.mtd_angle_range[1], int(np.sqrt(num_mtds)), endpoint=True)
dists = np.linspace(scenario.mtd_dist_range[0], scenario.mtd_dist_range[1], int(np.sqrt(num_mtds)), endpoint=True)

a, r = np.meshgrid(angles, dists)

mtds_angles = a.flatten()
mtds_dists = r.flatten()

# Calculates an average of the channel qualities:
channel_qualities = np.zeros((num_mtds, scenario.num_time_slots))

for n in range(n_realizations):
    
    channel_coeffs = channel.generateChannelCoefficients(num_mtds, random_upos=False, mtds_angles=mtds_angles, mtds_dists=mtds_dists)
    channel_qualities += np.abs(channel_coeffs)**2

channel_qualities /= n_realizations
uplink_snrs = 10*np.log10(channel_qualities * scenario.mtd_tx_power / scenario.noise_power)

for i in range(scenario.num_time_slots):

    Z = uplink_snrs[:, i].reshape((40,40))
    ax.pcolormesh(a, r, Z, cmap=my_cmap, shading="auto", vmin=-10, vmax=80)
    ax.set_xticklabels([])
    ax.set_yticklabels([])
    ax.set_xlim([0, np.pi])
    ax.set_ylim([0, scenario.mtd_dist_range[1]])
    ax.grid()

    fig.savefig("results/Figure 5/Slot_"+str(i+1)+".pdf")

    ax.clear()

norm = Normalize(vmin=-10, vmax=80)
colorbar = plt.pcolormesh(a, r, Z, cmap=my_cmap, shading="auto", vmin=-10, vmax=80)

fig = plt.figure(figsize=(10, 3))
ax = fig.add_axes([0.05, 0.3, 0.9, 0.02])  # Adicionar um eixo para a colorbar

colorbar = ColorbarBase(ax, cmap=my_cmap, norm=norm, orientation="horizontal")

colorbar.set_label("SNR [dB]", fontsize=12)

fig.savefig("results/Figure 5/Heatmap_Label.pdf")